var shuffleSequence = seq("setcounter","intro","prac1",sepWith("sep", seq(randomize("practice"))), "prac2",sepWith("sep", seq(rshuffle("npz-a","npz-b"))),"outro");
var practiceItemTypes = ["practice"];
var practiceItemMessage = "Practice sentence";
var pageTitle = "Reading experiment";
var completionMessage = "The data have been saved, thank you! Your code: 109F869D";
var progressBarText = "Progress";

var defaults = [
    "Separator", {
        transfer: 1000,
        normalMessage: "Please wait for the next sentence."
    },
    "ReversibleDashedSentence2", {
        mode: "self-paced reading",
        practiceItemMessage: "Practice sentence"
    },
    "Question", {
        hasCorrect: false,
        randomOrder: false
    },
    "Message", {
        hideProgressBar: false
    },
    "Form", {
        hideProgressBar: true,
        continueOnReturn: true,
        saveReactionTime: false,
        continueMessage: "Click here to continue"
    }
];

var items = [
["intro", "Form", {
        html: { include: "rspr_intro.html" }
                } ],
                ["prac1", "Form", {
        html: { include: "rspr_prac1.html" }
                } ],
                ["prac2", "Form", {
        html: { include: "rspr_prac2.html" }
                } ],
    ["outro", "Form", {
        html: { include: "rspr_outro.html" }
                } ], 
    ["sep", "Separator", { }],
    ["setcounter", "__SetCounter__", { }],
    ["practice", "ReversibleDashedSentence2", {s: ["The key","to the cabinets","unsurprisingly","was rusty","from years of disuse,","so","the janitor","threw it away."]},"Question", {q: "Was the sentence acceptable?", as: ["Yes","No","Don't know"]}],
    ["practice", "ReversibleDashedSentence2", {s: ["The new executives","who","oversaw","the middle manager","apparently","doubted themselves","on most major decisions."]},"Question", {q: "Was the sentence acceptable?", as: ["Yes","No","Don't know"]}],
[["npz-a",69], "ReversibleDashedSentence2", {s: ["The busy guide","noted","that","while","the mob","watched,","the juggler","swallowed","a silver sword","that","was very sharp."]},"Question", {q: "Was the sentence acceptable?", as: ["Yes","No","Don't know"]}],
[["npz-a",70], "ReversibleDashedSentence2", {s: ["One sole hiker","spotted","that","while","those men","hunted,","the moose","hurried","into the woods","and took cover."]},"Question", {q: "Was the sentence acceptable?", as: ["Yes","No","Don't know"]}],
[["npz-a",71], "ReversibleDashedSentence2", {s: ["Their sad tutor","moaned","that","though","both boys","phoned,","the coach","refused","to permit them","to join the team."]},"Question", {q: "Was the sentence acceptable?", as: ["Yes","No","Don't know"]}],
[["npz-a",72], "ReversibleDashedSentence2", {s: ["The idle boy","noticed","that","while","the baby","watched,","her mother","prepared","a new bottle","of powdered milk."]},"Question", {q: "Was the sentence acceptable?", as: ["Yes","No","Don't know"]}],
[["npz-a",73], "ReversibleDashedSentence2", {s: ["The local man","stated","that","after","the vet","visited,","the farmer","admitted","that","some of his animals","were ill."]},"Question", {q: "Was the sentence acceptable?", as: ["Yes","No","Don't know"]}],
[["npz-a",74], "ReversibleDashedSentence2", {s: ["The alert judge","mused","that","though","the dog","sniffed,","his trainer","avoided","all further attempts","to teach him tricks."]},"Question", {q: "Was the sentence acceptable?", as: ["Yes","No","Don't know"]}],
[["npz-a",75], "ReversibleDashedSentence2", {s: ["The farm hand","believed","that","while","the fox","stalked,","the geese","continued","to peck","at grain","on the ground."]},"Question", {q: "Was the sentence acceptable?", as: ["Yes","No","Don't know"]}],
[["npz-a",76], "ReversibleDashedSentence2", {s: ["The calm aide","stressed","that","after","the nun","helped,","the refugee","recovered slowly","in the camp","near the river."]},"Question", {q: "Was the sentence acceptable?", as: ["Yes","No","Don't know"]}],
[["npz-a",77], "ReversibleDashedSentence2", {s: ["The high lord","implied","that","while","the maid","dressed,","the queen","dismissed","all the other ladies","in the room."]},"Question", {q: "Was the sentence acceptable?", as: ["Yes","No","Don't know"]}],
[["npz-a",78], "ReversibleDashedSentence2", {s: ["The wary guest","related","that","after","the girl","awoke,","her father","shouted","in anger","about being disturbed","so early."]},"Question", {q: "Was the sentence acceptable?", as: ["Yes","No","Don't know"]}],
[["npz-a",79], "ReversibleDashedSentence2", {s: ["The new NCO","recorded","that","after","the cadet","saluted,","the major","ordered","the sergeant","to prepare","the ammunition."]},"Question", {q: "Was the sentence acceptable?", as: ["Yes","No","Don't know"]}],
[["npz-a",80], "ReversibleDashedSentence2", {s: ["The recent hack","revealed","that","after","the diva","married,","her agent","secured her","a lucrative contract","with the theater."]},"Question", {q: "Was the sentence acceptable?", as: ["Yes","No","Don't know"]}],
[["npz-a",81], "ReversibleDashedSentence2", {s: ["The news show","stated","that","while","the team","trained,","the striker","wondered","whether","the damage","would take long to heal."]},"Question", {q: "Was the sentence acceptable?", as: ["Yes","No","Don't know"]}],
[["npz-a",82], "ReversibleDashedSentence2", {s: ["The daily newspaper","claimed","that","after","the crowd","heckled,","the comic","appeared","to cut his act short","in humiliation."]},"Question", {q: "Was the sentence acceptable?", as: ["Yes","No","Don't know"]}],
[["npz-a",83], "ReversibleDashedSentence2", {s: ["The miners","all gloated","that","after","the reps","lobbied,","the union","directed","its committee","to approve","the proposal."]},"Question", {q: "Was the sentence acceptable?", as: ["Yes","No","Don't know"]}],
[["npz-a",84], "ReversibleDashedSentence2", {s: ["The wise agent","heard","that","while","the crew","filmed,","the actress","stormed off","the set of the film","in a tantrum."]},"Question", {q: "Was the sentence acceptable?", as: ["Yes","No","Don't know"]}],
[["npz-a",85], "ReversibleDashedSentence2", {s: ["The keen fan","lamented","that","after","the boxer","fought,","the medic","carried","a stretcher","to the side","of the ring."]},"Question", {q: "Was the sentence acceptable?", as: ["Yes","No","Don't know"]}],
[["npz-a",86], "ReversibleDashedSentence2", {s: ["The old groom","showed","that","though","the horse","kicked,","the trainer","remained calm","and managed","to avoid getting hurt."]},"Question", {q: "Was the sentence acceptable?", as: ["Yes","No","Don't know"]}],
[["npz-a",87], "ReversibleDashedSentence2", {s: ["The new headmaster","observed","that","while","the woman","taught,","the pupils","realized","that","they could now","solve the equations."]},"Question", {q: "Was the sentence acceptable?", as: ["Yes","No","Don't know"]}],
[["npz-a",88], "ReversibleDashedSentence2", {s: ["The grill cook","remarked","that","after","the boss","ordered,","the waiter","mumbled","the details","to the chef","incorrectly."]},"Question", {q: "Was the sentence acceptable?", as: ["Yes","No","Don't know"]}],
[["npz-a",89], "ReversibleDashedSentence2", {s: ["The hotel maid","joked","that","while","the woman","bathed,","her husband","announced","that","he","wanted","to have a shower."]},"Question", {q: "Was the sentence acceptable?", as: ["Yes","No","Don't know"]}],
[["npz-a",90], "ReversibleDashedSentence2", {s: ["The war diary","argued","that","after","the army","attacked,","the rebels","launched","a counter-attack","and inflicted huge losses."]},"Question", {q: "Was the sentence acceptable?", as: ["Yes","No","Don't know"]}],
[["npz-a",91], "ReversibleDashedSentence2", {s: ["The male nurse","spotted","that","after","the fire","burned,","the workman","labored","to make sure","the area","was secure."]},"Question", {q: "Was the sentence acceptable?", as: ["Yes","No","Don't know"]}],
[["npz-a",92], "ReversibleDashedSentence2", {s: ["The desk clerk","swore","that","while","the temp","assisted,","the tycoon","committed","a series","of white collar financial crimes."]},"Question", {q: "Was the sentence acceptable?", as: ["Yes","No","Don't know"]}],

[["npz-b",69], "ReversibleDashedSentence2", {s: ["The busy guide","noted","that","while","the mob","watched","the juggler","swallowed","a silver sword","that","was very sharp."]},"Question", {q: "Was the sentence acceptable?", as: ["Yes","No","Don't know"]}],
[["npz-b",70], "ReversibleDashedSentence2", {s: ["One sole hiker","spotted","that","while","those men","hunted","the moose","hurried","into the woods","and took cover."]},"Question", {q: "Was the sentence acceptable?", as: ["Yes","No","Don't know"]}],
[["npz-b",71], "ReversibleDashedSentence2", {s: ["Their sad tutor","moaned","that","though","both boys","phoned","the coach","refused","to permit them","to join the team."]},"Question", {q: "Was the sentence acceptable?", as: ["Yes","No","Don't know"]}],
[["npz-b",72], "ReversibleDashedSentence2", {s: ["The idle boy","noticed","that","while","the baby","watched","her mother","prepared","a new bottle","of powdered milk."]},"Question", {q: "Was the sentence acceptable?", as: ["Yes","No","Don't know"]}],
[["npz-b",73], "ReversibleDashedSentence2", {s: ["The local man","stated","that","after","the vet","visited","the farmer","admitted","that","some of his animals","were ill."]},"Question", {q: "Was the sentence acceptable?", as: ["Yes","No","Don't know"]}],
[["npz-b",74], "ReversibleDashedSentence2", {s: ["The alert judge","mused","that","though","the dog","sniffed","his trainer","avoided","all further attempts","to teach him tricks."]},"Question", {q: "Was the sentence acceptable?", as: ["Yes","No","Don't know"]}],
[["npz-b",75], "ReversibleDashedSentence2", {s: ["The farm hand","believed","that","while","the fox","stalked","the geese","continued","to peck","at grain","on the ground."]},"Question", {q: "Was the sentence acceptable?", as: ["Yes","No","Don't know"]}],
[["npz-b",76], "ReversibleDashedSentence2", {s: ["The calm aide","stressed","that","after","the nun","helped","the refugee","recovered slowly","in the camp","near the river."]},"Question", {q: "Was the sentence acceptable?", as: ["Yes","No","Don't know"]}],
[["npz-b",77], "ReversibleDashedSentence2", {s: ["The high lord","implied","that","while","the maid","dressed","the queen","dismissed","all the other ladies","in the room."]},"Question", {q: "Was the sentence acceptable?", as: ["Yes","No","Don't know"]}],
[["npz-b",78], "ReversibleDashedSentence2", {s: ["The wary guest","related","that","after","the girl","awoke","her father","shouted","in anger","about being disturbed","so early."]},"Question", {q: "Was the sentence acceptable?", as: ["Yes","No","Don't know"]}],
[["npz-b",79], "ReversibleDashedSentence2", {s: ["The new NCO","recorded","that","after","the cadet","saluted","the major","ordered","the sergeant","to prepare","the ammunition."]},"Question", {q: "Was the sentence acceptable?", as: ["Yes","No","Don't know"]}],
[["npz-b",80], "ReversibleDashedSentence2", {s: ["The recent hack","revealed","that","after","the diva","married","her agent","secured her","a lucrative contract","with the theater."]},"Question", {q: "Was the sentence acceptable?", as: ["Yes","No","Don't know"]}],
[["npz-b",81], "ReversibleDashedSentence2", {s: ["The news show","stated","that","while","the team","trained","the striker","wondered","whether","the damage","would take long to heal."]},"Question", {q: "Was the sentence acceptable?", as: ["Yes","No","Don't know"]}],
[["npz-b",82], "ReversibleDashedSentence2", {s: ["The daily newspaper","claimed","that","after","the crowd","heckled","the comic","appeared","to cut his act short","in humiliation."]},"Question", {q: "Was the sentence acceptable?", as: ["Yes","No","Don't know"]}],
[["npz-b",83], "ReversibleDashedSentence2", {s: ["The miners","all gloated","that","after","the reps","lobbied","the union","directed","its committee","to approve","the proposal."]},"Question", {q: "Was the sentence acceptable?", as: ["Yes","No","Don't know"]}],
[["npz-b",84], "ReversibleDashedSentence2", {s: ["The wise agent","heard","that","while","the crew","filmed","the actress","stormed off","the set of the film","in a tantrum."]},"Question", {q: "Was the sentence acceptable?", as: ["Yes","No","Don't know"]}],
[["npz-b",85], "ReversibleDashedSentence2", {s: ["The keen fan","lamented","that","after","the boxer","fought","the medic","carried","a stretcher","to the side","of the ring."]},"Question", {q: "Was the sentence acceptable?", as: ["Yes","No","Don't know"]}],
[["npz-b",86], "ReversibleDashedSentence2", {s: ["The old groom","showed","that","though","the horse","kicked","the trainer","remained calm","and managed","to avoid getting hurt."]},"Question", {q: "Was the sentence acceptable?", as: ["Yes","No","Don't know"]}],
[["npz-b",87], "ReversibleDashedSentence2", {s: ["The new headmaster","observed","that","while","the woman","taught","the pupils","realized","that","they could now","solve the equations."]},"Question", {q: "Was the sentence acceptable?", as: ["Yes","No","Don't know"]}],
[["npz-b",88], "ReversibleDashedSentence2", {s: ["The grill cook","remarked","that","after","the boss","ordered","the waiter","mumbled","the details","to the chef","incorrectly."]},"Question", {q: "Was the sentence acceptable?", as: ["Yes","No","Don't know"]}],
[["npz-b",89], "ReversibleDashedSentence2", {s: ["The hotel maid","joked","that","while","the woman","bathed","her husband","announced","that","he","wanted","to have a shower."]},"Question", {q: "Was the sentence acceptable?", as: ["Yes","No","Don't know"]}],
[["npz-b",90], "ReversibleDashedSentence2", {s: ["The war diary","argued","that","after","the army","attacked","the rebels","launched","a counter-attack","and inflicted huge losses."]},"Question", {q: "Was the sentence acceptable?", as: ["Yes","No","Don't know"]}],
[["npz-b",91], "ReversibleDashedSentence2", {s: ["The male nurse","spotted","that","after","the fire","burned","the workman","labored","to make sure","the area","was secure."]},"Question", {q: "Was the sentence acceptable?", as: ["Yes","No","Don't know"]}],
[["npz-b",92], "ReversibleDashedSentence2", {s: ["The desk clerk","swore","that","while","the temp","assisted","the tycoon","committed","a series","of white collar financial crimes."]},"Question", {q: "Was the sentence acceptable?", as: ["Yes","No","Don't know"]}],

];
