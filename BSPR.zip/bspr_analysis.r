#########################

# BSPR workshop
# Summer School of Linguistics 2022, Ceske Budejovice
# Dario Paape

#########################

# BSPR code: 
# https://www.ling.uni-potsdam.de/~paape/BSPR.zip

# Preprocess data file: Get rid of comment lines, put fixation sequences in quotes using regular expressions 

# #.*\n
# ,([0-9]+|-1|,)+,false
# ,"\1",false

# Install packages scanpath, em2

# library("devtools");
# install_github("tmalsburg/scanpath/scanpath", dependencies=TRUE)

# https://mran.microsoft.com/snapshot/2014-08-18_0233/web/packages/em2/index.html

# This function spreads the data frame to contain one line per fixation
# (This could probably be done better/more efficiently - feel free to modify)

sprd<-function (line) {
  dt <- line$V10
  splt <- unlist(strsplit(as.character(dt),","))
  splt <- str_replace(splt," ","")
  splt<-split.default(splt, rep(1:(length(splt)/3), each = 3))
  rps<-do.call("rbind", replicate(length(splt), line, simplify = FALSE))
  df<-data.table(matrix(unlist(splt), nrow=length(splt), byrow=TRUE))
  names(df)<-c("fixno","fixdur","dir")
  df$fixno<-as.numeric(df$fixno)
  df$fixdur<-as.numeric(df$fixdur)
  return(cbind(dplyr::select(line,-V10),data.frame(df)))
}

# Some more packages to load

library(plyr)
library(stringr)
library(data.table)
library(dplyr)

# Load data
# Still contains practice sentences, forms

results<-read.csv("bspr.csv",header=FALSE,encoding="UTF-8",sep=",",quote='"')
head(results)
unique(results$V3)
unique(results$V6)

# Only experimental sentences

results<-subset(results,V3=="ReversibleDashedSentence2"&V6%in%c("npz-a","npz-b"))

# Spread to get one line per fixation

rl <- alply(results, 1, sprd)
rl <- do.call(rbind, rl)

# Make unique trial IDs from subj SD, item ID

rl$trial<-paste(rl$V1,rl$V7)
length(unique(rl$trial))

# Take care to always keep the correct order, otherwise downstream calculations (reading measures, scanpaths) will be incorrect!

rl <- rl[order(rl$V1,rl$trial,rl$fixno),]

# Select and rename columns of interest

head(rl)
rl <- rl %>% dplyr::select(V1,V6,V7,V8,V9,fixno,fixdur,dir,trial)
names(rl)[1:5] <- c("subj","cond","item","word","text")

# As with other methods (SPR, ET), reading times have a fat right tail

hist(rl$fixdur,breaks=70)
summary(rl$fixdur)

# Remove some outliers. I treat RT<150 as a "skip"
# Note: You might want to keep RT<150 for the scanpath analysis!

rl <- subset(rl,fixdur>150&fixdur<5000)

library(em2)

# Word/region number must be numeric, otherwise em2 will complain

rl$word<-as.numeric(rl$word)

# Calculate reading time measures

meas <- em2(rl$word,rl$fixdur,trialinfo=dplyr::select(rl,subj,item,trial,cond))

# Sometimes the trialinfo part doesn't work properly. In this case, extract info manually and merge to result

txt<-unique(dplyr::select(rl,trial,word,text))
meas <- left_join(meas,txt,by = c("trial","roi"="word"))

# If sentences have different numbers of regions, you will get many NA/0 columns
# Remove those
meas <- subset(meas, FPRT>150)

# Reading measures also have long right tails

hist(meas$FPRT,breaks=70)
hist(log(meas$FPRT),breaks=70)

# You can now analyze the measures

summary(lm(log(FPRT)~nchar(text),meas))

### Scanpath analysis ###

library(scanpath)
library(ggplot2)

# Read Titus' scanpath tutorial here:
# https://github.com/tmalsburg/scanpath

# Let's do some visualization first
# Select a subset of trials

trls<-1:20
sub<-subset(rl,trial%in%unique(rl$trial)[trls])

# I like to look at proportional reading time: Time taken to look at a word as a proportion of the total time of the trial

sub<-sub%>%dplyr::group_by(trial)%>%dplyr::mutate(sumdur=sum(fixdur))
sub$propdur<-sub$fixdur/sub$sumdur
sub<-droplevels(sub)

# Trial has to be a factor, otherwise the package will complain

sub$trial<-factor(sub$trial)

# One way to plot scanpaths; the argument after the comma determines the colors

plot_scanpaths(sub,propdur ~ word | trial, item)+theme_light()

library(lme4)

# For the actual scanpath analysis, I residualize the log fixation durations against a bunch of nuisance variables first. This is because scasim and the clustering algorithm will pick up on *any* differences between scanpaths, including some people reading slower than others. If that's what you're *interested* in, don't do this, or at least don't remove the between-subject variability.

rl$length<-nchar(rl$text)
summary(resm<-lmer(log(fixdur)~scale(length)+scale(word)+(scale(length)+scale(word)|subj)+(1|item),rl))
m<-min(residuals(resm))
rl$resfixdur<-residuals(resm)-m

# Create fake X and Y coordinates because scasim needs those

rl$y<-50
rl$x<-rl$word*50
rl$trial<-factor(rl$trial)

# This other kind of visualization is not really all that useful for BSPR data:

# See scasim manual for detailed explanation of this calculation. I basically eliminated the complex calculation that has to do with visual acuity, because we're not really dealing with coordinates here.

sc_rl<-scasim(rl,resfixdur ~  x + y | trial,modulator=0,center_x=200.11,center_y=50,viewing_distance=60,unit_size=1/30,normalize="durations")

# Output is an n_trials by n_trials dissimilarity matrix

sc_rl[1:4,1:4]

# Needs to be mapped into an n-dimensional space using multidimensional scaling (MDS)

library(vegan)

# The algo can't figure out the optimal k (number of dimensions) by itself
# Try different values of k and look at the stress. Stress < 0.10 is good but higher values are acceptable if the dimensions are more interpretable.

map_rl<-monoMDS(sc_rl,k=3)
map_rl$stress

library(mclust)

# Feed the resulting k-dimensional map into the clustering algo

mod_rl <- Mclust(map_rl$points)
plot(mod_rl,what="classification")
summary(mod_rl)

# Reduce number of clusters according to entropy criterion
# (You don't have to do this, but I recommend it)
# Baudry, J.-P., Raftery, A. E., Celeux, G., Lo, K., & Gottardo, R. (2010). Combining mixture components for clustering. Journal of Computational and Graphical Statistics, 19 (2), 332-353. doi: 10.1198/jcgs.2010.08111

cc_rl<-clustCombi(mod_rl)
summary(cc_rl,parameters=TRUE)
cco_rl<-clustCombiOptim(cc_rl,reg=2)

# See how many clusters you got

length(unique(cco_rl$cluster.combi))

# Extract classification and dimensions, merge with data

trc<-data.frame(trial=row.names(sc_rl),cluster=cco_rl$cluster.combi,d1=map_rl$points[,1],d2=map_rl$points[,2],d3=map_rl$points[,3])
nrow(rl)
rl<-left_join(rl,trc,by = c("trial"))
nrow(rl)
head(rl)

# Now we can select scanpaths that are high/low on a particular dimension, and/or that belong to particular clusters, and plot them

#sub<-subset(rl,trial%in%unique(rl$trial)[1:40])
sub<-subset(rl,d3%in%sort(unique(rl$d3),decreasing=FALSE)[1:10])
sub<-sub%>%dplyr::group_by(trial)%>%dplyr::mutate(sumdur=sum(fixdur))
sub$propdur<-sub$fixdur/sub$sumdur
sub<-droplevels(sub)
sub$trial<-factor(sub$trial)
sub$cluster<-factor(sub$cluster)
plot_scanpaths(sub,propdur ~ word | trial,cluster)+theme_light()
