library(lme4)
library(stringr)
library(boot)
library(ggplot2)
library(languageR)
library(plyr)
library(MASS)
library(plotrix)
library(lme4)
library(xtable)

# Power calculation for Frazier & Clifton (2000)
psd <- ((56.4+54.7)/4)*sqrt(60)
power.t.test(n = 60, sd=psd, delta=50, sig.level = 0.05, power = NULL,type = c("paired"), alternative = c("two.sided"),strict = FALSE)

# Power calculation for current experiment
psd <- ((34.5+33.8)/4)*sqrt(60)
power.t.test(n = 60, sd=psd, delta=32, sig.level = 0.05, power = NULL,type = c("paired"), alternative = c("two.sided"),strict = FALSE)

# Read in data
data <- readRDS("paape_data.rds")
data$region <- iconv(data$region,"latin1","UTF-8")

# Get only question responses
ques <- droplevels(subset(data, pos == "?" | pos == "!"))
colnames(ques)[7]<-"correct"
ques$correct <- as.numeric(as.character(ques$correct))

# Only questions for experimental items
eq <- subset(ques, exp == "soel")
boxcox(eq$rt ~ eq$gender * eq$order)
eq$rrt <- -1000/sqrt(eq$rt)
eq$rrt <- scale(eq$rrt, scale=F)
eq$gender<-ifelse(eq$cond%in%c("a","b"),1,-1)
eq$order<-ifelse(eq$cond%in%c("a","c"),1,-1)

# Nested contrasts
eq$c1<-ifelse(eq$cond=="a",1,ifelse(eq$cond=="b",-1,0))
eq$c2<-ifelse(eq$cond=="c",1,ifelse(eq$cond=="d",-1,0))
eq$c3<-ifelse(eq$cond%in%c("a","b"),1,-1)

# Questions targeting argument structure (gp) and the wh element (wh)
eq$gp <- ifelse(eq$item%in%c(3,6,7,8,16,19,21,22,23,25,28,31),1,-1)
eq$wh <- ifelse(eq$item%in%c(2,4,10,11,13,15,20,26),1,-1)

# Logistic regression on comprehension accuracies
summary(q3 <- glmer(correct ~ gender * order * rrt + (1|ei) + (1|subj)+ (0+gender|subj)+(0+order|subj)+(0+order|ei), data=eq, family=binomial(link="logit")))
summary(q1 <- glmer(correct ~ gender * order * gp + (1|ei) + (1|subj)+(0+order|subj)+(0+order|ei), data=eq, family=binomial(link="logit")))
summary(q1b <- glmer(correct ~ c1+c2+c3 + rrt + (1|ei) + (1|subj)+ (0+gender|subj)+(0+order|subj)+(0+gender|ei)+(0+order|ei), data=eq, family=binomial(link="logit")))

# Question response accuracies by question type
eq$qtype <- ifelse(eq$wh == 1, "wh",ifelse(eq$gp == 1,"as","other"))
ddply(.data=eq, .(qtype),summarize,mean(correct))

# Question response accuracies by subject
acc1 <- ddply(.data=ques, .(subj),summarize,mean(correct))
mean(acc1[,2])
acc2 <- ddply(.data=eq, .(subj),summarize,mean(correct))
mean(acc2[,2])

# Get only non-question responses
data <- droplevels(subset(data, pos != "?" & pos != "!"))

# Convert to reciprocal reading times
data$rrt <- -1000/data$rt

# Code the experimental manipulations
data$gender<-ifelse(data$cond%in%c("a","b"),1,-1)
data$order<-ifelse(data$cond%in%c("a","c"),1,-1)
# Nested contrasts
data$c1<-ifelse(data$cond=="a",1,ifelse(data$cond=="b",-1,0))
data$c2<-ifelse(data$cond=="c",1,ifelse(data$cond=="d",-1,0))
data$c3<-ifelse(data$cond%in%c("a","b"),1,-1)

# To see whether presence of a pronoun influences result
data$pro<-ifelse(data$ei%in%c("soel 1","soel 3","soel 8","soel 9","soel 32"),1,-1)

data$rlength <- nchar(as.character(data$region),type="bytes")
data$res <- residuals(lmer(rt~rlength+(0+rlength|subj),data))

# Add reading times for the preceding region; backup needed for first region
databaq <- data
data$pos <- as.numeric(as.character(data$pos))
datacopy <- data[, c(1,4,5,9,10)]
datacopy$pos <- as.numeric(as.character(datacopy$pos))+1
colnames(datacopy)[5]<-"prev"
datacopy$prev<-scale(datacopy$prev,scale=FALSE)
data<-merge(data,datacopy,by.x=c("subj","cond","pos","ei"),by.y=c("subj","cond","pos","ei"))

# Get only critical sentences
data <- droplevels(subset(data, exp == "soel"))
boxcox(data$rt ~ data$gender*data$order)

# Add reading times for np2, wh-1 and wh+3
ant <- subset(data,roi == "np2")[,c(1,4,10)]
effr <- subset(data,roi == "wh+3")[,c(1,4,10)]
colnames(ant)[3] <- "ant"
colnames(effr)[3] <- "wh3"
ant$ant <- unlist(scale(ant$ant, scale=F))
effr$wh3 <- unlist(scale(effr$wh3, scale=F))
data <- merge(data, ant, by.x=c("subj","ei"), by.y=c("subj","ei"))
eq <- merge(eq, ant, by.x=c("subj","ei"), by.y=c("subj","ei"))
eq <- merge(eq, effr, by.x=c("subj","ei"), by.y=c("subj","ei"))

# Subset for regions of interest
np1 <- subset(databaq, roi=="np1")
adj <- subset(data, roi=="adj")
vp <- subset(data,roi=="vp")
aux <- subset(data, roi=="aux")
np2 <- subset(data, roi=="np2")
wh <- subset(data, roi=="wh")
wh1n <- subset(data, roi=="wh-1")
wh2n <- subset(data, roi=="wh-2")
wh3n <- subset(data, roi=="wh-3")
wh4n <- subset(data, roi=="wh-4")
aber <- subset(data, roi=="aber")
wh1 <- subset(data, roi=="wh+1")
wh2 <- subset(data, roi=="wh+2")
wh3 <- subset(data, roi=="wh+3")
wh4 <- subset(data, roi=="wh+4")
wh5 <- subset(data, roi=="wh+5")

# Table of mean RTs
tdata<-droplevels(subset(databaq,roi%in%c("np1","aux","np2","adj","vp","wh-1","wh","wh+1","wh+2","wh+3")))
xtable(round(xtabs(rt~roi+cond,aggregate(rt~roi+cond,tdata,mean))))
round(xtabs(rt~roi+cond,aggregate(rt~roi+cond,tdata,std.error)))

# Region np1 has a lot of extreme values; model fitted after removing those fits no better than null model; results are not reported in paper since there was no explicit hypothesis for this region
summary(m_np1 <- lmer(rrt ~ gender * order + (1|subj) + (1|ei) +(0+gender|subj)+(0+order|subj), subset(np1,rt > 150 & rt > 4000)))
summary(m_np1z <- lmer(rrt ~ 1 + (1|subj) + (1|ei) +(0+gender|subj)+(0+order|subj), subset(np1,rt > 150 & rt > 4000)))
anova(m_np1,m_np1z)
plot(density(np1$rt))

# aux
summary(m1 <- lmer(rrt ~ gender * order + prev + (1|subj) + (1|ei) +(0+gender|subj)+(0+order|subj), subset(aux,rt > 150)))
(res.table <- as.data.frame(coef(summary(m1))))
xtable(res.table,hline.after=c(1),floating=FALSE)

# np2
summary(m2 <- lmer(rrt ~ gender * order + prev + (1|subj) + (1|ei) +(0+gender|subj)+(0+order|subj)+(0+gender|ei)+(0+order|ei)+(0+gender:order|subj)+(0+gender:order|ei), subset(np2,rt > 150)))
(res.table <- as.data.frame(coef(summary(m2))))
xtable(res.table,hline.after=c(1),floating=FALSE)
summary(m2a <- lmer(rrt ~ gender + order + prev + (1|subj) + (1|ei) +(0+gender|subj)+(0+order|subj)+(0+gender|ei)+(0+order|ei)+(0+gender:order|subj)+(0+gender:order|ei), subset(np2,rt > 150)))
anova(m2,m2a)
summary(m2b <- lmer(rrt ~ c1+c2+c3 + prev + (1|subj) + (1|ei) +(0+gender|subj)+(0+order|subj)+(0+gender|ei)+(0+order|ei)+(0+gender:order|subj)+(0+gender:order|ei), subset(np2,rt > 150)))

# adj
summary(m3 <- lmer(rrt ~ gender * order + prev + (1|subj) + (1|ei) +(0+gender|subj)+(0+order|subj)+(0+order|ei)+(0+gender:order|subj), subset(adj,rt > 150)))
(res.table <- as.data.frame(coef(summary(m3))))
xtable(res.table,hline.after=c(1),floating=FALSE)

# wh-1
summary(m4 <- lmer(rrt ~ gender * order + prev + (1|subj) + (1|ei) +(0+gender|subj)+(0+order|subj)+(0+gender|ei), subset(wh1n,rt > 150)))
(res.table <- as.data.frame(coef(summary(m4))))
xtable(res.table,hline.after=c(1),floating=FALSE)
summary(m4a <- lmer(rrt ~ gender + order + prev + (1|subj) + (1|ei) +(0+gender|subj)+(0+order|subj)+(0+gender|ei), subset(wh1n,rt > 150)))
anova(m4,m4a)
summary(m4b <- lmer(rrt ~ c1+c2+c3 + prev + (1|subj) + (1|ei) +(0+gender|subj)+(0+order|subj)+(0+gender|ei), subset(wh1n,rt > 150)))

# wh+2
summary(m5 <- lmer(rrt ~ gender * order + prev +(1|subj) + (1|ei) +(0+gender|subj), subset(wh2,rt > 150)))
(res.table <- as.data.frame(coef(summary(m5))))
xtable(res.table,hline.after=c(1),floating=FALSE)
# Removing the outlier
summary(m5x <- lmer(rrt ~ gender * order + prev + (1|subj) + (1|ei) +(0+gender|subj), subset(wh2,rt > 177)))
plot(fitted(m5x),residuals(m5x))

# wh+3
summary(m6 <- lmer(rrt ~ gender * order + prev + (1|subj) + (1|ei) +(0+gender|subj)+(0+order|subj)+(0+order|ei)+(0+gender:order|subj), subset(wh3,rt > 150)))
(res.table <- as.data.frame(coef(summary(m6))))
xtable(res.table,hline.after=c(1),floating=FALSE)
summary(m6a <- lmer(rrt ~ gender + order + prev + (1|subj) + (1|ei) +(0+gender|subj)+(0+order|subj)+(0+order|ei)+(0+gender:order|subj), subset(wh3,rt > 150)))
anova(m6,m6a)
summary(m6b <- lmer(rrt ~ c1+c2+c3 + prev + (1|subj) + (1|ei) +(0+gender|subj)+(0+order|subj)+(0+order|ei)+(0+gender:order|subj), subset(wh3,rt > 150)))
# With pro
summary(m6c <- lmer(rrt ~ gender * order + pro + prev + (1|subj) + (1|ei) +(0+gender|subj)+(0+order|subj)+(0+order|ei)+(0+gender:order|subj), subset(wh3,rt > 150)))
# With ant
summary(m6d <- lmer(rrt ~ gender * order + ant + prev + (1|subj) + (1|ei) +(0+gender|subj)+(0+order|subj)+(0+order|ei)+(0+gender:order|subj), subset(wh3,rt > 150)))
# Only trials with correct responses
wh3m <- merge(eq[,c(1,2,8)], wh3, by.x=c("subj","ei"), by.y=c("subj","ei"))
wh3c <- subset(wh3m, correct == 1)
nrow(wh3c)/nrow(wh3m)
summary(m6e <- lmer(rrt ~ gender * order + prev + (1|subj) + (1|ei) +(0+gender|subj)+(0+order|subj)+(0+order|ei)+(0+gender:order|subj), subset(wh3c,rt > 150)))
## With antecedent reading time
summary(m6f <- lmer(rrt ~ gender * order + ant + prev + (1|subj) + (1|ei) +(0+gender|subj)+(0+order|subj)+(0+order|ei)+(0+gender:order|subj), subset(wh3c,rt > 150)))

qqnorm(residuals(m1))
qqline(residuals(m1))

plot(residuals(m1),fitted(m1))
acf(residuals(m1))

# Compare the garden-path condition with the other conditions
ca <- subset(wh3, cond == "a")
std.error(ca$rt)
median(ca$rt)
std.error(data$rt)
median(data$rt)
plot(density(ca$rt))

# Hartigan's dip test
library(diptest)
dip.test(ca$rt)

# Compute variance inflation factor
# From: https://raw.githubusercontent.com/aufrank/R-hacks/master/mer-utils.R

vif.mer <- function (fit) {
  ## adapted from rms::vif
  
  v <- vcov(fit)
  nam <- names(fixef(fit))
  
  ## exclude intercepts
  ns <- sum(1 * (nam == "Intercept" | nam == "(Intercept)"))
  if (ns > 0) {
    v <- v[-(1:ns), -(1:ns), drop = FALSE]
    nam <- nam[-(1:ns)]
  }
  
  d <- diag(v)^0.5
  v <- diag(solve(v/(d %o% d)))
  names(v) <- nam
  v
}

vif.mer(m1)

# From: http://www.cookbook-r.com/Manipulating_data/Summarizing_data/

summarySE <- function(data=NULL, measurevar, groupvars=NULL, na.rm=FALSE,
                      conf.interval=.95, .drop=TRUE) {
  require(plyr)
  
  # New version of length which can handle NA's: if na.rm==T, don't count them
  length2 <- function (x, na.rm=FALSE) {
    if (na.rm) sum(!is.na(x))
    else       length(x)
  }
  
  # This does the summary. For each group's data frame, return a vector with
  # N, mean, and sd
  datac <- ddply(data, groupvars, .drop=.drop,
                 .fun = function(xx, col) {
                   c(N    = length2(xx[[col]], na.rm=na.rm),
                     mean = mean   (xx[[col]], na.rm=na.rm),
                     sd   = sd     (xx[[col]], na.rm=na.rm)
                   )
                 },
                 measurevar
  )
  
  # Rename the "mean" column    
  datac <- rename(datac, c("mean" = measurevar))
  
  datac$se <- datac$sd / sqrt(datac$N)  # Calculate standard error of the mean
  
  # Confidence interval multiplier for standard error
  # Calculate t-statistic for confidence interval: 
  # e.g., if conf.interval is .95, use .975 (above/below), and use df=N-1
  ciMult <- qt(conf.interval/2 + .5, datac$N-1)
  datac$ci <- datac$se * ciMult
  
  return(datac)
}

require(grid)

# Plot means + error bars
data_el <- subset(data,roi%in%c("wh-1","wh","wh+1","wh+2","wh+3") & rt > 150 & rt < 4000 & rrt > -5)
data_el$nom <- ifelse(data_el$roi == "wh-1",1,ifelse(data_el$roi == "wh",2,ifelse(data_el$roi == "wh+1",3,ifelse(data_el$roi == "wh+2",4,5))))
data_el$Condition <- ifelse(data_el$cond=="a","OVS amb.",ifelse(data_el$cond=="b","SVO amb.",ifelse(data_el$cond=="c","OVS unamb.","SVO unamb.")))

(dfc1 <- summarySE(data_el, measurevar="res", groupvars=c("Condition","nom")))

lbs=c("wh-1","wh","wh+1","wh+2","wh+3")
pd <- position_dodge(.2)
cbPalette <- c("#FF33CC", "#0099FF", "#006600","#FF6600")
setEPS()
postscript("plot1.eps",width=15)
ggplot(dfc1, aes(x=nom, y=res, color = Condition, shape=Condition)) + 
  scale_shape_manual(values=c(15,16,22,21)) +                  
  scale_linetype_manual(values=c("dashed", "dotted","solid","twodash"))+
  geom_errorbar(aes(ymin=res-ci, ymax=res+ci), width=.1,size=1,position=pd) +
  geom_line(aes(linetype=Condition),size=1,position=pd) +
  geom_point(size=8,position=pd,fill="white") +
  scale_x_continuous(breaks=seq(1, 5, 1),labels=lbs)+
  scale_y_continuous(breaks=seq(-125, 100, 25))+
  scale_colour_manual(values=cbPalette) +
  theme(axis.title.x = element_text(face="bold", size=25),
        axis.text.x = element_text(color="black",size=20),
        axis.title.y = element_text(face="bold", size=25),
        axis.text.y = element_text(color="black",size=20),
        legend.title = element_text(face="bold", size=25),
        #legend.key.width = unit(2.5, "cm"),
        #legend.position = "top",
        legend.text = element_text(color="black",size=24))+
  ylab("Residual reading time (ms)")+
  xlab("Region")
dev.off()

data_a <- subset(databaq,roi%in%c("np1","aux","np2","adj","vp") & rt > 150 & rt < 4000 & rrt > -5)
data_a$nom <- ifelse(data_a$roi == "np1",1,ifelse(data_a$roi == "aux",2,ifelse(data_a$roi == "np2",3,ifelse(data_a$roi == "adj",4,5))))
data_a$Condition <- ifelse(data_a$cond=="a","OVS amb.",ifelse(data_a$cond=="b","SVO amb.",ifelse(data_a$cond=="c","OVS unamb.","SVO unamb.")))

(dfc2 <- summarySE(data_a, measurevar="res", groupvars=c("Condition","nom")))
(dfc2_b <- summarySE(subset(data_a,nom==3), measurevar="rt", groupvars=c("Condition","nom")))

lbs=c("np1","aux","np2","adj","vfin")
pd <- position_dodge(.2)
cbPalette <- c("#FF33CC", "#0099FF", "#006600","#FF6600")
setEPS()
postscript("plot2.eps",width=15)
ggplot(dfc2, aes(x=nom, y=res, color = Condition, shape=Condition)) + 
  scale_shape_manual(values=c(15,16,22,21)) +                  
  scale_linetype_manual(values=c("dashed", "dotted","solid","twodash"))+
  geom_errorbar(aes(ymin=res-ci, ymax=res+ci), width=.1,size=1,position=pd) +
  geom_line(aes(linetype=Condition),size=1,position=pd) +
  geom_point(size=8,position=pd,fill="white") +
  scale_x_continuous(breaks=seq(1, 5, 1),labels=lbs)+
  scale_y_continuous(breaks=seq(-150, 275, 25))+
  scale_colour_manual(values=cbPalette) +
  theme(axis.title.x = element_text(face="bold", size=25),
        axis.text.x = element_text(color="black",size=20),
        axis.title.y = element_text(face="bold", size=25),
        axis.text.y = element_text(color="black",size=20),
        legend.title = element_text(face="bold", size=25),
        legend.key.width = unit(2.5, "cm"),
        #legend.position = "top",
        legend.text = element_text(color="black",size=18))+
  ylab("Residual reading time (ms)")+
  xlab("Region")
dev.off()

