library(rstan)
library(polspline)

# Plot Bayes factor results for Experiment 2
# Note that the numbers shown in the plots are hard-coded

png(file='bfplots2.png',height=6,width=5,units="in",res=300)

par(mfrow=c(3,2),mar=c(2,2,3,2))

load("bf2_ 0.1 - -Inf - 0 .Rda")
summary(bf_mod1)
samples <- data.frame(extract(bf_mod1)) # It saves all the samples from the model.
post <- samples$beta_3

fit_posterior <- logspline(post,ubound=0)
#summary(fit_posterior)
posterior <- dlogspline(0, fit_posterior) # Height of the posterior at 0
prior <- dnorm(0, 0, 0.1/2)
(posterior/prior)
plot(fit_posterior,what="d",col="red",xlim=c(-0.1,0),ylim=c(0,100),xaxp  = c(-0.1, 0, 4),main="sd = 0.1, right-truncated\nBF01 = 2.41")
x<-seq(0,0.1,0.01)
curve( dnorm(x,mean=0,sd=0.1/2), add=T,to=0,col="blue")
abline(v=0,lty=2)

load("bf2_ 0.1 - 0 - Inf .Rda")
samples <- data.frame(extract(bf_mod1)) # It saves all the samples from the model.
post <- samples$beta_3

fit_posterior <- logspline(post,lbound=0)
#summary(fit_posterior)
posterior <- dlogspline(0, fit_posterior) # Height of the posterior at 0
prior <- dnorm(0, 0, 0.1/2)
(posterior/prior)
plot(fit_posterior,what="d",col="red",xlim=c(0,0.1),ylim=c(0,100),xaxp  = c(0, 0.1, 4),main="sd = 0.1, left-truncated\nBF01 = 22.20")
x<-seq(-0.1,0,0.01)
curve( dnorm(x,mean=0,sd=0.1/2), add=T,from=0,col="blue")
abline(v=0,lty=2)

load("bf2_ 0.05 - -Inf - 0 .Rda")
samples <- data.frame(extract(bf_mod1)) # It saves all the samples from the model.
post <- samples$beta_3

fit_posterior <- logspline(post,ubound=0)
#summary(fit_posterior)
posterior <- dlogspline(0, fit_posterior) # Height of the posterior at 0
prior <- dnorm(0, 0, 0.05/2)
(posterior/prior)
plot(fit_posterior,what="d",col="red",xlim=c(-0.1,0),ylim=c(0,100),xaxp  = c(-0.1, 0, 4),main="sd = 0.05, right-truncated\nBF01 = 1.27")
x<-seq(0,0.1,0.01)
curve( dnorm(x,mean=0,sd=0.05/2), add=T,to=0,col="blue")
abline(v=0,lty=2)

load("bf2_ 0.05 - 0 - Inf .Rda")
samples <- data.frame(extract(bf_mod1)) # It saves all the samples from the model.
post <- samples$beta_3

fit_posterior <- logspline(post,lbound=0)
#summary(fit_posterior)
posterior <- dlogspline(0, fit_posterior) # Height of the posterior at 0
prior <- dnorm(0, 0, 0.05/2)
(posterior/prior)
plot(fit_posterior,what="d",col="red",xlim=c(0,0.1),ylim=c(0,100),xaxp  = c(0, 0.1, 4),main="sd = 0.05, left-truncated\nBF01 = 11.58")
x<-seq(-0.1,0,0.01)
curve( dnorm(x,mean=0,sd=0.05/2), add=T,from=0,col="blue")
abline(v=0,lty=2)

load("bf2_ 0.01 - -Inf - 0 .Rda")
samples <- data.frame(extract(bf_mod1)) # It saves all the samples from the model.
post <- samples$beta_3

fit_posterior <- logspline(post,ubound=0)
#summary(fit_posterior)
posterior <- dlogspline(0, fit_posterior) # Height of the posterior at 0
prior <- dnorm(0, 0, 0.01/2)
(posterior/prior)
plot(fit_posterior,what="d",col="red",xlim=c(-0.1,0),ylim=c(0,200),xaxp  = c(-0.1, 0, 4),main="sd = 0.01, right-truncated\nBF01 = 1.58")
x<-seq(0,0.1,0.01)
curve( dnorm(x,mean=0,sd=0.01/2), add=T,to=0,col="blue")
abline(v=0,lty=2)

load("bf2_ 0.01 - 0 - Inf .Rda")
samples <- data.frame(extract(bf_mod1)) # It saves all the samples from the model.
post <- samples$beta_3

fit_posterior <- logspline(post,lbound=0)
#summary(fit_posterior)
posterior <- dlogspline(0, fit_posterior) # Height of the posterior at 0
prior <- dnorm(0, 0, 0.01/2)
(posterior/prior)
plot(fit_posterior,what="d",col="red",xlim=c(0,0.1),ylim=c(0,200),xaxp  = c(0, 0.1, 4),,main="sd = 0.01, left-truncated\nBF01 = 3.14")
x<-seq(-0.1,0,0.01)
curve( dnorm(x,mean=0,sd=0.01/2), add=T,from=0,col="blue")
abline(v=0,lty=2)
dev.off()


