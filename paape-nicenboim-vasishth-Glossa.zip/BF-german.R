library(plyr)
library(rstan)
library(polspline)

# Bayes factors for ellipsis site in Experiment 1 (German data)

fit <- function(pars){
	dat_el <- list(subject=as.integer(factor(el$subj)),
               item=as.integer(factor(el$item)),
               x=el$rrt, ## dep. var.        
               el = el$el,
               comp = el$comp,
               prior_sd = pars[1]/2,
               lo = pars[2],
               up = pars[3],
               N = nrow(el),
               I = length(unique(el$subj)),
               K = length(unique(el$item)))

params<-c("inter","beta_1","beta_2","beta_3","sigma_e","sigma_u","sigma_w")

bf_mod1 <- stan(file="bfs.stan",
				control=list(adapt_delta=.99),
                iter=4000,
                chains=4,
                cores=4,
                warmup=2000,
                data=dat_el,
                pars=params,
                refresh=-1)

name <- paste("bf_",pars[1],"-",pars[2],"-",pars[3],".Rda")
save(bf_mod1,file=name)
print(bf_mod1,probs = c(0.025,0.975),digits_summary=4)

samples <- data.frame(extract(bf_mod1)) # It saves all the samples from the model.
post <- samples$beta_1

if (pars[2] == 0) {fit_posterior <- logspline(post,lbound=0)} else if (pars[3] == 0) {fit_posterior <- logspline(post,ubound=0)}
#summary(fit_posterior)
posterior <- dlogspline(0, fit_posterior) # Height of the posterior at 0
prior <- dnorm(0, 0, pars[1]/2)
return(posterior/prior)
}

data <- read.table("data")
data <- subset(data, V1 != "1")
sdata <- data
colnames(sdata) <- c("subj","exp","item","condition","pos","word","roi","rt")
sdata$rrt <- -1000/sdata$rt

# GERMAN ONLY

cdata <- subset(sdata, roi != 1 & roi != 0 & exp%in%c("strip"))
cdata$comp <- ifelse(cdata$condition%in%c("b","e"),1,-1)
cdata$el <- ifelse(cdata$condition%in%c("a","b"),1,-1)

el <- subset(cdata,roi=="ebf" & rt > 150)

(f1 <- fit(c(0.1,0,Inf)))
(f2 <- fit(c(0.05,0,Inf)))
(f3 <- fit(c(0.01,0,Inf)))
(f4 <- fit(c(0.1,-Inf,0)))
(f5 <- fit(c(0.05,-Inf,0)))
(f6 <- fit(c(0.01,-Inf,0)))
