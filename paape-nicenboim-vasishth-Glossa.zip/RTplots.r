library(ggplot2)
library(plyr)

data <- read.table("data",encoding="UTF-8")
data <- subset(data, V1 != "1")
sdata <- data
colnames(sdata) <- c("subj","exp","item","condition","pos","word","roi","rt")
data2 <- read.table("b1data")
data3 <- read.table("b2data")
data2$V1 <- paste(data2$V1, "-b1")
data3$V1 <- paste(data3$V1, "-b2")
data2$V2 <- paste(data2$V2, "-b1")
data3$V2 <- paste(data3$V2, "-b2")
bdata <- rbind(data2,data3)
colnames(bdata) <- c("subj","exp","item","condition","pos","word","roi","rt")
data$V3 <- paste(data$V3, "-ger")
data <- rbind(data,data2,data3)
colnames(data) <- c("subj","exp","item","condition","pos","word","roi","rt")
data$rrt <- -1000/data$rt
bdata$rrt <- -1000/bdata$rt
sdata$rrt <- -1000/sdata$rt

badata <- droplevels(subset(sdata, roi%in%c("ebf","+1","+2","ebf-1","ebf-2") & rt > 150))
badata$ba <- ifelse(badata$roi%in%c("ebf-1","ebf-2"),-1,1)
badata$comp <- ifelse(badata$condition%in%c("b","e"),1,-1)
badata$el <- ifelse(badata$condition%in%c("a","b"),1,-1)
badata$nom <- ifelse(badata$roi%in%c("el-2","ebf-2"),1,ifelse(badata$roi%in%c("ebf-1","el-1"),2,ifelse(badata$roi%in%c("ebf","el"),3,ifelse(badata$roi%in%c("+1"),4,5))))
badata$Comp <- ifelse(badata$condition%in%c("a","d"),"Simple","Complex")
badata$Ell <- ifelse(badata$condition%in%c("a","b"),"Ellipsis","Control")
badata$Condition <- paste(badata$Comp, badata$Ell)

library(scales)

badata$Condition = factor(badata$Condition,levels(factor(badata$Condition))[c(4,3,2,1)])
(dfc2 <- ddply(.data=badata, .(Condition,nom), summarize, mn=mean(rt),ci=1.96*std.error(rt)))
(dfc2a <- ddply(.data=badata, .(Condition,nom), summarize, mn=-1000/mean(rrt),cih=-1000/(mean(rrt)+(1.96*std.error(rrt))),cil=-1000/(mean(rrt)-(1.96*std.error(rrt)))))

lbs=c("crit-2\nthe clever commander","crit-1\nof the insurgents","critical\nas well, / advanced,","crit+1\nwithout","crit+2\nhowever")
pd <- position_dodge(.4)
cbPalette <- c("#FF33CC", "#0099FF","#006600","#FF6600")
png("plot1.png",width=17,height=10,units = 'in', res = 300)
ggplot(dfc2a, aes(x=nom, y=mn, color = Condition, shape=Condition)) + 
  scale_shape_manual(values=c(15,16,22,21)) +                  
  scale_linetype_manual(values=c("dashed", "dotted","solid","twodash"))+
  #geom_errorbar(aes(ymin=cl, ymax=ch), width=.2,size=1,position=pd,color="darkgrey") +
  geom_errorbar(aes(ymin=cil, ymax=cih), width=.2,size=1,position=pd) +
  geom_line(aes(linetype=Condition),size=1,position=pd) +
  geom_point(size=8,position=pd,fill="white") +
  scale_x_continuous(breaks=seq(1, 5, 1),labels=lbs)+
  scale_y_continuous(breaks=pretty_breaks(10))+
  scale_colour_manual(values=cbPalette) +
  theme_bw()+
  theme(axis.title.x = element_text(face="bold", size=25),
        axis.text.x = element_text(color="black",size=20),
        axis.title.y = element_text(face="bold", size=25),
        axis.text.y = element_text(color="black",size=20),
        legend.title = element_text(face="bold", size=25),
        panel.grid.minor=element_blank(),
        panel.grid.major.x=element_blank(),
        legend.key.width = unit(2.5, "cm"),
        #legend.position = "top",
        legend.text = element_text(color="black",size=18))+
  ylab("Reading time (ms)")+
  xlab("Region")
  #coord_trans(y=reciprocal_trans())
dev.off()

badata2 <- droplevels(subset(bdata, roi%in%c("el","el+1","el+2","el-1","el-2") & rt > 150))
badata2$comp <- ifelse(badata2$condition == "b",1,-1)
badata2$grp <- ifelse(badata2$exp == "el -b1",-1,ifelse(badata2$exp == "el -b2",1,0))

badata2$nom <- ifelse(badata2$roi%in%c("el-2"),1,ifelse(badata2$roi%in%c("el-1"),2,ifelse(badata2$roi%in%c("el"),3,ifelse(badata2$roi%in%c("el+1"),4,5))))
badata2$Comp <- ifelse(badata2$condition%in%c("a","d"),"Simple","Complex")
badata2$Grp <- ifelse(badata2$grp==1,"Detailed","Superficial")
badata2$Condition <- paste(badata2$Grp,badata2$Comp)

badata2$Condition = factor(badata2$Condition,levels(factor(badata2$Condition))[c(4,3,2,1)])
head(badata2)
(dfc2b <- ddply(.data=badata2, .(Condition,nom), summarize, mn=-1000/mean(rrt),cih=-1000/(mean(rrt)+(1.96*std.error(rrt))),cil=-1000/(mean(rrt)-(1.96*std.error(rrt)))))

lbs=c("crit-2\nthat","crit-1\nthe mathematics lecturer","critical\ndid not,","crit+1\nas","crit+2\nthe time-consuming ...")
pd <- position_dodge(.4)
cbPalette <- c("#FF33CC", "#0099FF","#006600","#FF6600")
png("plot2.png",width=17,height=10,units = 'in', res = 300)
ggplot(dfc2b, aes(x=nom, y=mn, color = Condition, shape=Condition)) + 
  scale_shape_manual(values=c(15,16,22,21)) +                  
  scale_linetype_manual(values=c("dashed", "dotted","solid","twodash"))+
  #geom_errorbar(aes(ymin=cl, ymax=ch), width=.2,size=1,position=pd,color="darkgrey") +
  geom_errorbar(aes(ymin=cil, ymax=cih), width=.2,size=1,position=pd) +
  geom_line(aes(linetype=Condition),size=1,position=pd) +
  geom_point(size=8,position=pd,fill="white") +
  scale_x_continuous(breaks=seq(1, 5, 1),labels=lbs)+
  scale_y_continuous(breaks=pretty_breaks(10))+
  scale_colour_manual(values=cbPalette) +
  theme_bw()+
  theme(axis.title.x = element_text(face="bold", size=25),
        axis.text.x = element_text(color="black",size=20),
        axis.title.y = element_text(face="bold", size=25),
        axis.text.y = element_text(color="black",size=20),
        legend.title = element_text(face="bold", size=25),
        legend.key.width = unit(2.5, "cm"),
        panel.grid.minor=element_blank(),
        panel.grid.major.x=element_blank(),
        #legend.position = "top",
        legend.text = element_text(color="black",size=18))+
  ylab("Reading time (ms)")+
  xlab("Region")
  #coord_trans(y=reciprocal_trans())
dev.off()