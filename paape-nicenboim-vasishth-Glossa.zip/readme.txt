data - Raw data from Experiment 1
b1data - Raw data from Experiment 2 (Superficial probe group)
b2data - Raw data from Experiment 2 (Detailed probe group)

run_models.R - Main data analysis script

RTplots.R - Script for generating the RT plots

BF-german.R - Script for Bayes factor analysis of Experiment 1
bfs.stan - Corresponding Stan code

BF-english.R - Script for Bayes factor analysis of Experiment 2
bf2s.stan - Corresponding Stan code

caterpillar.R - Script for generating the caterpillar plots

plot-BF-german.R - Script for generating the Bayes factor plots for Experiment 1
plot-BF-english.R - Script for generating the Bayes factor plots for Experiment 2
