library(lme4)
library(lattice)
library(rstanarm)
library(ggplot2)
library(plyr)
library(stringr)

# Show summaries and make caterpillar plots for all the models

capi <- function(model,title,brks,lmts){
mname<-model
model<-get(load(model))
summary <- round(summary(model,probs = c(0.025,0.975)),3)
summ <- data.frame(summary)
summ <- round(summ,3)
summ$param <- rownames(summ)
summ<-subset(summ,!substring(param,1,1)%in%c("(","b")&!param%in%c("log-posterior","mean_PPD","sigma")&substring(param,1,3)!="roi")
names(summ)<-c("mean","mcse","sd","low","high","n_eff","Rhat","param")
summ$param <-gsub("roi5-4","diff(+1/+2)",summ$param)
summ$param <-gsub("roi4-3","diff(cr/+1)",summ$param)
summ$param <-gsub("roi3-2","diff(-1/cr)",summ$param)
summ$param <-gsub("roi2-1","diff(-2/-1)",summ$param)
summ$param <-gsub("logrt","log_rt",summ$param)
summ$param <-gsub("grp","p_type",summ$param)
summ$odr <- ifelse(grepl("diff(-2/-1)",summ$param,fixed=TRUE),0,ifelse(grepl("diff(-1/cr)",summ$param,fixed=TRUE),1,ifelse(grepl("diff(cr/+1)",summ$param,fixed=TRUE),2,ifelse(grepl("diff(+1/+2)",summ$param,fixed=TRUE),3,-1))))
summ$cnt <- str_count(summ$param, ":")
summ$param <-factor(summ$param, levels=summ[order(-summ$cnt,-nchar(summ$param),-summ$odr), "param"])
df <- data.frame(model)
print(summ)
print(sapply(df[1:nrow(summ)+1],function(x) round(mean(x > 0),2)))
p<-ggplot(summ,aes(x = summ$param,y = summ$mean))+
geom_hline(yintercept=0,color="indianred2")+
geom_errorbar(aes(ymin=low, ymax=high), width=0,size=1,color="darkgrey")+
geom_point(size=2)+
scale_y_continuous(breaks=brks,limits=lmts)+
guides(size=FALSE,shape=FALSE)+
coord_flip()+
ggtitle(title)+
theme_bw() + xlab("") + ylab("")+
theme(axis.text.x=element_text(size=rel(1)),
               axis.title.x=element_text(size=rel(1)),
               axis.text.y=element_text(size=rel(1)),
               axis.title.y=element_text(size=rel(1)),
               panel.grid.minor=element_blank(),
               panel.grid.major.x=element_blank(),
               plot.title = element_text(size=rel(1)))
(pname <- paste(as.character(mname),".eps"))
return(p)
}

library(gridExtra)

#setEPS()
#postscript("plots.eps")

png(file='qplots.png',height=4,width=5,units = 'in', res = 300)
#par(mfrow = c(2,3))
p1 <- capi("samples_ger_qa.Rda","Question response accuracy (logit scale)",seq(-1.5, 1.5, .5),c(-1.5, 1.5))
p2 <- capi("samples_ger_qr.Rda","Question response time (log scale)",seq(-0.1, 0.1, .05),c(-0.1, 0.1))
grid.arrange(p1, p2, ncol=1, bottom="Estimate",left="Parameter")
dev.off()

png(file='plots.png',height=6,width=6,units = 'in', res = 300)
#par(mfrow = c(2,3))
brks=seq(-0.25, 0.05, .1)
lmts=c(-0.25, 0.05)
p1 <- capi("samples_ger_m1.Rda","crit-2\nthe clever commander",brks,lmts)
p2 <- capi("samples_ger_m2.Rda","crit-1\nof the insurgents",brks,lmts)
p3 <- capi("samples_ger_el.Rda","crit\nas well, / advanced,",brks,lmts)
p4 <- capi("samples_ger_p1.Rda","crit+1\nwithout",brks,lmts)
p5 <- capi("samples_ger_p2.Rda","crit+2\nhowever",brks,lmts)
grid.arrange(p1, p2, p3, p4, p5, ncol=2, bottom="Estimate",left="Parameter")
dev.off()

png(file='qplots2.png',height=4,width=5,units = 'in', res = 300)
#par(mfrow = c(2,3))
p1 <- capi("samples_en_qa.Rda","Question response accuracy (logit scale)",seq(-1.5, 0.5, .5),c(-1.5, 0.5))
p2 <- capi("samples_en_qr.Rda","Question response time (log scale)",seq(-0.1, 0.35, .1),c(-0.1, 0.35))
grid.arrange(p1, p2, ncol=1, bottom="Estimate",left="Parameter")
dev.off()

png(file='plots2.png',height=6,width=6,units = 'in', res = 300)
#par(mfrow = c(2,3))
brks=seq(-0.15, 0.15, .1)
lmts=c(-0.15, 0.15)
p1 <- capi("samples_en_m1.Rda","crit-2\nthat",brks,lmts)
p2 <- capi("samples_en_m2.Rda","crit-1\nthe mathematics lecturer",brks,lmts)
p3 <- capi("samples_en_el.Rda","crit\ndid not,",brks,lmts)
p4 <- capi("samples_en_p1.Rda","crit+1\nas",brks,lmts)
p5 <- capi("samples_en_p2.Rda","crit+2\nthe time-consuming...",brks,lmts)
grid.arrange(p1, p2, p3, p4, p5, ncol=2, bottom="Estimate",left="Parameter")
dev.off()

png(file='plotbigger.png',height=4,width=5,units = 'in', res = 300)
#par(mfrow = c(2,3))
brks=seq(-0.25, 0.25, .1)
lmts=c(-0.25, 0.25)
p1 <- capi("samples_ger_big.Rda","",brks,lmts)
grid.arrange(p1,ncol=1, bottom="Estimate",left="Parameter")
dev.off()

png(file='plotbigen.png',height=4,width=5,units = 'in', res = 300)
#par(mfrow = c(2,3))
brks=seq(-0.1, 0.1, .05)
lmts=c(-0.1, 0.1)
p1 <- capi("samples_en_big.Rda","",brks,lmts)
grid.arrange(p1,ncol=1, bottom="Estimate",left="Parameter")
dev.off()

png(file='plotnest.png',height=2,width=5,units = 'in', res = 300)
#par(mfrow = c(2,3))
brks=seq(-0.1, 0.1, .05)
lmts=c(-0.1, 0.1)
p1 <- capi("samples_en_qr_nested.Rda","",brks,lmts)
grid.arrange(p1,ncol=1, bottom="Estimate",left="Parameter")
dev.off()
