library(plyr)
library(rstan)
library(rstanarm)
library(MASS)

citation(package="rstanarm")

# Read in data
# "data" = German data (Experiment 1), "b1data" = English data, superficial probe group (Experiment 2), "b2data" = English data, detailed probe group (Experiment 2)
data <- read.table("data",encoding="UTF-8")
data <- subset(data, V1 != "1")
sdata <- data
colnames(sdata) <- c("subj","exp","item","condition","pos","word","roi","rt")
data2 <- read.table("b1data")
data3 <- read.table("b2data")
data2$V1 <- paste(data2$V1, "-b1")
data3$V1 <- paste(data3$V1, "-b2")
data2$V2 <- paste(data2$V2, "-b1")
data3$V2 <- paste(data3$V2, "-b2")
bdata <- rbind(data2,data3)
colnames(bdata) <- c("subj","exp","item","condition","pos","word","roi","rt")
data$V3 <- paste(data$V3, "-ger")
data <- rbind(data,data2,data3)
colnames(data) <- c("subj","exp","item","condition","pos","word","roi","rt")
# Calculate reciprocal RTs
data$rrt <- -1000/data$rt
bdata$rrt <- -1000/bdata$rt
sdata$rrt <- -1000/sdata$rt


### Experiment 1 - GERMAN ###


# Unique trial identifiers for random effect in big model
sdata$sentence <- as.numeric(as.character(sdata$subj))*100+as.numeric(as.character(sdata$item))

# Throw out question responses and fillers
cdata <- subset(sdata, roi != 1 & roi != 0 & exp%in%c("strip"))

# Sum coding of factors
# comp = Complexity (-1 = simple, 1 = complex)
# el = Elision (-1 = control, 1 = ellipsis)
cdata$comp <- ifelse(cdata$condition%in%c("b","e"),1,-1)
cdata$el <- ifelse(cdata$condition%in%c("a","b"),1,-1)

# Suggests 1/RT transform
tdata<-subset(cdata,rt>150)
boxcox(tdata$rt~tdata$el*tdata$comp)

# Code ROI predictor and fit big model with by-trial random intercept
badata <- droplevels(subset(cdata, roi%in%c("ebf","+1","+2","ebf-1","ebf-2") & rt > 150))
badata$roi <- factor(badata$roi,levels(badata$roi)[c(5,4,3,1,2)])
library(ic.infer)
contrasts(badata$roi) = contr.diff(5)
contrasts(badata$roi)
summary(mod_big_ger <- stan_lmer(rrt ~ comp * el*roi+(comp*el*roi|subj)+(comp*el*roi|item)+(1|sentence), data=badata,cores=4,iter=4000,adapt_delta=0.99),digits=3,probs = c(0.025,0.975))
dr <- as.matrix(mod_big_ger)
mean(dr[,1]>0)
mean(dr[,2]>0)
mean(dr[,3]>0)
mean(dr[,4]>0)
mean(dr[,5]>0)
mean(dr[,6]>0)
mean(dr[,7]>0)
mean(dr[,8]>0)
mean(dr[,9]>0)
mean(dr[,10]>0)
mean(dr[,11]>0)
mean(dr[,12]>0)
mean(dr[,13]>0)
mean(dr[,14]>0)
mean(dr[,15]>0)
mean(dr[,16]>0)
mean(dr[,17]>0)
mean(dr[,18]>0)
mean(dr[,19]>0)
mean(dr[,20]>0)
save(mod_big_ger,file="samples_ger_big.Rda")

# Analyses of question response accuracy and latency
qdata <- subset(sdata, roi%in%c(1,0) & exp=="strip")
qdata$comp <- ifelse(qdata$condition%in%c("b","e"),1,-1)
qdata$el <- ifelse(qdata$condition%in%c("a","b"),1,-1)
qdata$logrt <- scale(log(qdata$rt),scale=F)
summary(mod_q_ger <- stan_glmer(roi ~ comp*el+logrt +(comp*el+logrt|subj)+(comp*el+logrt|item),data=qdata,family=binomial(link="logit"),iter=4000,adapt_delta=0.99,cores=4),digits=3,probs = c(0.025,0.975))
dr <- as.matrix(mod_q_ger)
mean(dr[,1]>0)
mean(dr[,2]>0)
mean(dr[,3]>0)
mean(dr[,4]>0)
mean(dr[,5]>0)
save(mod_q_ger,file="samples_ger_qa.Rda")
summary(mod_qr_ger <- stan_lmer(log(rt) ~ comp*el +(comp*el|subj)+(comp*el|item),data=qdata,iter=4000,adapt_delta=0.99,cores=4),digits=3,probs = c(0.025,0.975))
dr <- as.matrix(mod_qr_ger)
mean(dr[,1]>0)
mean(dr[,2]>0)
mean(dr[,3]>0)
mean(dr[,4]>0)
save(mod_qr_ger,file="samples_ger_qr.Rda")

# By-region analyses

m2 <- subset(cdata, roi%in%c("ebf-2"))
m1 <- subset(cdata, roi%in%c("ebf-1"))
p1 <- subset(cdata, roi%in%c("+1"))
p2 <- subset(cdata, roi%in%c("+2"))
el <- subset(cdata, roi%in%c("ebf"))

test <- subset(el, rt > 150)
summary(mod_el_ger <- stan_lmer(rrt ~ comp * el+ (comp*el|subj)+(comp*el|item), data=test,iter=4000,adapt_delta=0.99,cores=4),digits=3,probs = c(0.025,0.975))
dr <- as.matrix(mod_el_ger)
mean(dr[,1]>0)
mean(dr[,2]>0)
mean(dr[,3]>0)
mean(dr[,4]>0)
save(mod_el_ger,file="samples_ger_el.Rda")

test <- subset(p1, rt > 150)
summary(mod_p1_ger <- stan_lmer(rrt ~ comp * el+(comp*el|subj)+(comp*el|item), data=test,iter=4000,adapt_delta=0.99,cores=4),digits=3,probs = c(0.025,0.975))
dr <- as.matrix(mod_p1_ger)
mean(dr[,1]>0)
mean(dr[,2]>0)
mean(dr[,3]>0)
mean(dr[,4]>0)
save(mod_p1_ger,file="samples_ger_p1.Rda")

test <- subset(p2, rt > 150)
summary(mod_p2_ger <- stan_lmer(rrt ~ comp * el+(comp*el|subj)+(comp*el|item), data=test,iter=4000,adapt_delta=0.99,cores=4),digits=3,probs = c(0.025,0.975))
dr <- as.matrix(mod_p2_ger)
mean(dr[,1]>0)
mean(dr[,2]>0)
mean(dr[,3]>0)
mean(dr[,4]>0)
save(mod_p2_ger,file="samples_ger_p2.Rda")

test <- subset(m1, rt > 150)
summary(mod_m1_ger <- stan_lmer(rrt ~ comp * el+(comp*el|subj)+(comp*el|item),iter=4000,adapt_delta=0.99, data=test,cores=4),digits=3,probs = c(0.025,0.975))
dr <- as.matrix(mod_m1_ger)
mean(dr[,1]>0)
mean(dr[,2]>0)
mean(dr[,3]>0)
mean(dr[,4]>0)
save(mod_m1_ger,file="samples_ger_m1.Rda")

test <- subset(m2, rt > 150)
summary(mod_m2_ger <- stan_lmer(rrt ~ comp * el+(comp*el|subj)+(comp*el|item),iter=4000,adapt_delta=0.99, data=test,cores=4),digits=3,probs = c(0.025,0.975))
dr <- as.matrix(mod_m2_ger)
mean(dr[,1]>0)
mean(dr[,2]>0)
mean(dr[,3]>0)
mean(dr[,4]>0)
save(mod_m2_ger,file="samples_ger_m2.Rda")}



### Experiment 2 - ENGLISH ###


# Unique trial identifiers for random effect in big model
bdata$subj <- as.numeric(as.character(substr(bdata$subj,1,2)))
bdata$subj <- bdata$subj*100
bdata$subj <- ifelse(bdata$exp=="el -b2",bdata$subj+20000,bdata$subj+10000)
bdata$sentence <- as.numeric(as.character(bdata$subj))+as.numeric(as.character(bdata$item))

# Throw out question responses and fillers
cdata <- subset(bdata, roi != 1 & roi != 0 & exp%in%c("el -b1","el -b2"))

# Sum coding of factors
# comp = Complexity (-1 = simple, 1 = complex)
# grp = Probe type (-1 = superficial, 1 = detailed)
cdata$comp <- ifelse(cdata$condition=="a",-1,1)
cdata$grp <- ifelse(cdata$exp=="el -b1",-1,1)

# Again, suggests 1/RT transform
tdata<-subset(cdata,rt>150)
boxcox(tdata$rt~tdata$comp*tdata$grp)

library(lme4)
qqnorm(residuals(lmer(log(rt)~comp*grp+(1|subj)+(1|item),subset(cdata,rt>150))))
qqline(residuals(lmer(log(rt)~comp*grp+(1|subj)+(1|item),subset(cdata,rt>150))))

# Code ROI contrast for big model, fit model with by-trial random intercept
badata <- droplevels(subset(cdata, roi%in%c("el","el+1","el+2","el-1","el-2") & rt > 150))
badata$roi <- factor(badata$roi,levels(badata$roi)[c(4,2,1,3,5)])
library(ic.infer)
contrasts(badata$roi) = contr.diff(5)
contrasts(badata$roi)
summary(mod_big_en <- stan_lmer(rrt ~ comp * grp*roi+(comp*roi|subj)+(comp*grp*roi|item)+(1|sentence), data=badata,cores=4,iter=4000,adapt_delta=0.99),digits=3,probs=c(0.025,0.975))
dr <- as.matrix(mod_big_en)
mean(dr[,1]>0)
mean(dr[,2]>0)
mean(dr[,3]>0)
mean(dr[,4]>0)
mean(dr[,5]>0)
mean(dr[,6]>0)
mean(dr[,7]>0)
mean(dr[,8]>0)
mean(dr[,9]>0)
mean(dr[,10]>0)
mean(dr[,11]>0)
mean(dr[,12]>0)
mean(dr[,13]>0)
mean(dr[,14]>0)
mean(dr[,15]>0)
mean(dr[,16]>0)
mean(dr[,17]>0)
mean(dr[,18]>0)
mean(dr[,19]>0)
mean(dr[,20]>0)
save(mod_big_en,file="samples_en_big.Rda")

# Analyses of question response accuracy and latency
qdata <- subset(bdata, roi%in%c(1,0) & exp%in%c("el -b1","el -b2"))
qdata$comp <- ifelse(qdata$condition=="a",-1,1)
qdata$grp <- ifelse(qdata$exp=="el -b1",-1,1)
qdata$logrt <- scale(log(qdata$rt),scale=F)
summary(mod_q_en <- stan_glmer(roi ~ comp*grp+logrt +(comp+logrt|subj)+(comp*grp+logrt|item),data=qdata,family=binomial(link="logit"),iter=4000,adapt_delta=0.99,cores=4),digits=3,probs=c(0.025,0.975))
dr <- as.matrix(mod_q_en)
mean(dr[,1]>0)
mean(dr[,2]>0)
mean(dr[,3]>0)
mean(dr[,4]>0)
mean(dr[,5]>0)
save(mod_q_en,file="samples_en_qa.Rda")
summary(mod_qr_en <- stan_lmer(log(rt) ~ comp*grp +(comp|subj)+(comp*grp|item),data=qdata,iter=4000,adapt_delta=0.99,cores=4),digits=3,probs=c(0.025,0.975))
dr <- as.matrix(mod_qr_en)
mean(dr[,1]>0)
mean(dr[,2]>0)
mean(dr[,3]>0)
mean(dr[,4]>0)
save(mod_qr_en,file="samples_en_qr.Rda")

# By-region analyses

m1 <- subset(cdata, roi%in%c("el-1")) 
m2 <- subset(cdata, roi%in%c("el-2"))
p1 <- subset(cdata, roi%in%c("el+1"))
p2 <- subset(cdata, roi%in%c("el+2"))
el <- subset(cdata, roi%in%c("el"))

test <- subset(m2, rt > 150)
summary(mod_m2_en <- stan_lmer(rrt ~ comp*grp+(comp|subj)+(comp*grp|item), data=test,cores=4,adapt_delta=0.99,iter=4000),digits=3,probs=c(0.025,0.975))
dr <- as.matrix(mod_m2_en)
mean(dr[,1]>0)
mean(dr[,2]>0)
mean(dr[,3]>0)
mean(dr[,4]>0)
save(mod_m2_en,file="samples_en_m2.Rda")

test <- subset(m1, rt > 150)
summary(mod_m1_en <- stan_lmer(rrt ~ comp*grp+(comp|subj)+(comp*grp|item), data=test,cores=4,adapt_delta=0.99,iter=4000),digits=3,probs=c(0.025,0.975))
dr <- as.matrix(mod_m1_en)
mean(dr[,1]>0)
mean(dr[,2]>0)
mean(dr[,3]>0)
mean(dr[,4]>0)
save(mod_m1_en,file="samples_en_m1.Rda")

test <- subset(el, rt > 150)
summary(mod_el_en <- stan_lmer(rrt ~ comp*grp+(comp|subj)+(comp*grp|item), data=test,cores=4,adapt_delta=0.99,iter=4000),digits=3,probs=c(0.025,0.975))
dr <- as.matrix(mod_el_en)
mean(dr[,1]>0)
mean(dr[,2]>0)
mean(dr[,3]>0)
mean(dr[,4]>0)
save(mod_el_en,file="samples_en_el.Rda")

test <- subset(p1, rt > 150)
summary(mod_p1_en <- stan_lmer(rrt ~ comp*grp+(comp|subj)+(comp*grp|item), data=test,cores=4,adapt_delta=0.99,iter=4000),digits=3,probs=c(0.025,0.975))
dr <- as.matrix(mod_p1_en)
mean(dr[,1]>0)
mean(dr[,2]>0)
mean(dr[,3]>0)
mean(dr[,4]>0)
save(mod_p1_en,file="samples_en_p1.Rda")

test <- subset(p2, rt > 150)
summary(mod_p2_en <- stan_lmer(rrt ~ comp*grp+(comp|subj)+(comp*grp|item), data=test,cores=4,adapt_delta=0.99,iter=4000),digits=3,probs=c(0.025,0.975))
dr <- as.matrix(mod_p2_en)
mean(dr[,1]>0)
mean(dr[,2]>0)
mean(dr[,3]>0)
mean(dr[,4]>0)
save(mod_p2_en,file="samples_en_p2.Rda")

# To see if presence of comma interacts with position-related speedup
fdata <- subset(sdata,exp=="filler" & pos!="?")
fdata<-subset(fdata,rt>150)
summary(fdata)
fdata$word <- as.character(fdata$word)
fdata$comma <- ifelse(substr(fdata$word,nchar(fdata$word),nchar(fdata$word))==",",1,-1)
fdata$pos<-as.numeric(as.character(fdata$pos))
summary(mod_comma <- stan_lmer(rrt ~ comma*scale(pos,scale=F)+(comma*scale(pos,scale=F)|subj)+(comma*scale(pos,scale=F)|item), data=fdata,cores=4,iter=4000,adapt_delta=0.99),digits=3,probs = c(0.025,0.975))
dr <- as.matrix(mod_comma)
mean(dr[,1]>0)
mean(dr[,2]>0)
mean(dr[,3]>0)
mean(dr[,4]>0)
save(mod_comma,file="samples_comma.Rda")
