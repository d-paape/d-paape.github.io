# Code to generate plots for Experiment 1

library(plyr)
library(dplyr)
library(plotrix)

data <- read.table("data_fr.txt")

library(ggplot2)
library(gridExtra)
library(R.utils)
library(extrafont)

pd <- position_dodge(.3)
co<- c("#FF33CC", "#0099FF","#006600","#FF6600")

f <- theme(axis.title.x = element_text(face="bold", size=9),
           axis.text.x = element_text(color="black",size=8),
           axis.title.y = element_text(face="bold", size=9),
           axis.text.y = element_text(color="black",size=8),
           legend.title = element_text(face="bold", size=9),
           plot.title = element_text(face="bold",lineheight=.8,size=9),
           legend.text = element_text(color="black",size=9),
           legend.position = "top")

p <- filter(data,firrdt>0)
p$firrdt <- residuals(lm(log(firrdt)~scale(log(length),scale=F),p))
p$regrpd <- residuals(lm(log(regrpd)~scale(log(length),scale=F),p))
p$dwellt <- residuals(lm(log(dwellt)~scale(log(length),scale=F),p))

### RRC ###

p1 <- subset(p,roi%in%c("np1","part","pp","dis","post-dis","pre-sluice","sluice","spillover") & stype=="rrc")
p1$pos <- ifelse(p1$roi == "np1",1,ifelse(p1$roi == "part",2,ifelse(p1$roi =="pp",3,ifelse(p1$roi == "dis",4,ifelse(p1$roi == "post-dis",5,ifelse(p1$roi == "pre-sluice",6,ifelse(p1$roi == "spillover",7,8)))))))
p1$Condition <- ifelse(p1$condition=="a","ambiguous/ellipsis",ifelse(p1$condition=="b","unambiguous/ellipsis",ifelse(p1$condition=="c","ambiguous/control","unambiguous/control")))

lbs=c("np1\nLe/s navire/s ...","part\ndétruit/s","pp\ndurant la guerre","disamb.\navait/ent rejoint ...","post-disamb.\nle port,","pre-critical\n...","critical\nquand/n'en savait rien,","spillover\nlaissant ...")

# Plot first-pass reading times by region/condition
rrc_fp <- p1 %>% filter(firsfp==1) %>% group_by(Condition,pos) %>% dplyr::summarise(mfp=mean(firrdt),low=mean(firrdt)-1.96*std.error(firrdt),high=mean(firrdt)+1.96*std.error(firrdt)) %>% ggplot(aes(x=pos, y=mfp, color = Condition, shape=Condition)) + 
  scale_shape_manual(values=c(15,16,22,21)) +   
  theme_bw()+
  scale_linetype_manual(values=c("dashed", "dotted","solid","twodash"))+
  geom_errorbar(aes(ymin=low, ymax=high), width=.1,size=.5,position=pd) +
  geom_line(aes(linetype=Condition),size=.5,position=pd) +
  f+
  geom_point(size=2.5,position=pd,fill="white") +
  scale_x_continuous(breaks=seq(1, 8, 1),labels=lbs)+
  scale_y_continuous(breaks=seq(-5, 5, .1))+
  scale_colour_manual(values=co) +
  #coord_trans(y="log")+
  ylab("Length-corrected\nlog first-pass reading time")+
  xlab("Region")

# Plot regression-path durations by region/condition
rrc_rp <- p1 %>% filter(firsfp==1) %>% group_by(Condition,pos) %>% dplyr::summarise(mfp=mean(regrpd),low=mean(regrpd)-1.96*std.error(regrpd),high=mean(regrpd)+1.96*std.error(regrpd)) %>% ggplot(aes(x=pos, y=mfp, color = Condition, shape=Condition)) + 
  theme_bw()+
  scale_shape_manual(values=c(15,16,22,21)) +                  
  scale_linetype_manual(values=c("dashed", "dotted","solid","twodash"))+
  geom_errorbar(aes(ymin=low, ymax=high), width=.1,size=.5,position=pd) +
  geom_line(aes(linetype=Condition),size=.5,position=pd) +
  f+
  geom_point(size=2.5,position=pd,fill="white") +
  scale_x_continuous(breaks=seq(1, 8, 1),labels=lbs)+
  scale_y_continuous(breaks=seq(-5, 5, .1))+
  scale_colour_manual(values=co) +
  #coord_trans(y="log")+
  ylab("Length-corrected\nlog regression-path duration")+
  xlab("Region")

# Plot total reading time by region/condition
rrc_tt <- p1 %>% group_by(Condition,pos) %>% dplyr::summarise(mfp=mean(dwellt),low=mean(dwellt)-1.96*std.error(dwellt),high=mean(dwellt)+1.96*std.error(dwellt)) %>% ggplot(aes(x=pos, y=mfp, color = Condition, shape=Condition)) + 
  scale_shape_manual(values=c(15,16,22,21)) +      
  theme_bw()+
  scale_linetype_manual(values=c("dashed", "dotted","solid","twodash"))+
  geom_errorbar(aes(ymin=low, ymax=high), width=.1,size=.5,position=pd) +
  geom_line(aes(linetype=Condition),size=0.5,position=pd) +
  f+
  geom_point(size=2.5,position=pd,fill="white") +
  scale_x_continuous(breaks=seq(1, 8, 1),labels=lbs)+
  scale_y_continuous(breaks=seq(-5, 5, .1))+
  scale_colour_manual(values=co) +
  #coord_trans(y="log")+
  ylab("Length-corrected\nlog total reading time")+
  xlab("Region")

tiff("rrc-grid.tif",height=8.75,width=7.5,units='in',res=300,compression="lzw",family="Times New Roman")
grid.arrange(rrc_fp,rrc_rp,rrc_tt,ncol=1)
dev.off()

### SOI ###

p1 <- subset(p,roi%in%c("np1_1","np1_2","aux_v","np2_1","np2_2","sluice","so") & stype=="soi")
p1$pos <- ifelse(p1$roi == "np1_1",1,ifelse(p1$roi == "np1_2",2,ifelse(p1$roi =="aux_v",3,ifelse(p1$roi == "np2_1",4,ifelse(p1$roi == "np2_2",5,ifelse(p1$roi == "sluice",6,7))))))
p1$Condition <- ifelse(p1$condition=="a","non-canonical/ellipsis",ifelse(p1$condition=="b","canonical/ellipsis",ifelse(p1$condition=="c","non-canonical/control","canonical/control")))

lbs=c("np1_1\nQuel escrimeur","np1_2\nde l'équipe nationale","aux\na/ont salué","np2_1\nles adversaires","np2_2\ndu concours","critical\net quand,/avant la lutte,","spillover\nsi je puis ...")

# Plot first-pass reading times by region/condition
soi_fp <- p1 %>% filter(firsfp==1) %>% group_by(Condition,pos) %>% dplyr::summarise(mfp=mean(firrdt),low=mean(firrdt)-1.96*std.error(firrdt),high=mean(firrdt)+1.96*std.error(firrdt)) %>% ggplot(aes(x=pos, y=mfp, color = Condition, shape=Condition)) + 
  scale_shape_manual(values=c(15,16,22,21)) +  
  theme_bw()+
  scale_linetype_manual(values=c("dashed", "dotted","solid","twodash"))+
  geom_errorbar(aes(ymin=low, ymax=high), width=.1,size=.5,position=pd) +
  geom_line(aes(linetype=Condition),size=.5,position=pd) +
  f+
  geom_point(size=2.5,position=pd,fill="white") +
  scale_x_continuous(breaks=seq(1, 7, 1),labels=lbs)+
  scale_y_continuous(breaks=seq(-5, 5, .1))+
  scale_colour_manual(values=co) +
  #coord_trans(y="log")+
  ylab("Length-corrected\nlog first-pass reading time")+
  xlab("Region")

# Plot regression-path durations by region/condition
soi_rp <- p1 %>% filter(firsfp==1) %>% group_by(Condition,pos) %>% dplyr::summarise(mfp=mean(regrpd),low=mean(regrpd)-1.96*std.error(regrpd),high=mean(regrpd)+1.96*std.error(regrpd)) %>% ggplot(aes(x=pos, y=mfp, color = Condition, shape=Condition)) + 
  scale_shape_manual(values=c(15,16,22,21)) +    
  theme_bw()+
  scale_linetype_manual(values=c("dashed", "dotted","solid","twodash"))+
  geom_errorbar(aes(ymin=low, ymax=high), width=.1,size=.5,position=pd) +
  geom_line(aes(linetype=Condition),size=.5,position=pd) +
  f+
  geom_point(size=2.5,position=pd,fill="white") +
  scale_x_continuous(breaks=seq(1, 7, 1),labels=lbs)+
  scale_y_continuous(breaks=seq(-5, 5, .1))+
  scale_colour_manual(values=co) +
  #coord_trans(y="log")+
  ylab("Length-corrected\nlog regression-path duration")+
  xlab("Region")

# Plot total reading time by region/condition
soi_tt <- p1 %>% group_by(Condition,pos) %>% dplyr::summarise(mfp=mean(dwellt),low=mean(dwellt)-1.96*std.error(dwellt),high=mean(dwellt)+1.96*std.error(dwellt)) %>% ggplot(aes(x=pos, y=mfp, color = Condition, shape=Condition)) + 
  scale_shape_manual(values=c(15,16,22,21)) +    
  theme_bw()+
  scale_linetype_manual(values=c("dashed", "dotted","solid","twodash"))+
  geom_errorbar(aes(ymin=low, ymax=high), width=.1,size=.5,position=pd) +
  geom_line(aes(linetype=Condition),size=.5,position=pd) +
  f+
  geom_point(size=2.5,position=pd,fill="white") +
  scale_x_continuous(breaks=seq(1, 7, 1),labels=lbs)+
  scale_y_continuous(breaks=seq(-5, 5, .1))+
  scale_colour_manual(values=co) +
  #coord_trans(y="log")+
  ylab("Length-corrected\nlog total reading time")+
  xlab("Region")

tiff("soi-grid.tif",height=8.75,width=7.5,units='in',res=300,compression="lzw",family="Times New Roman")
grid.arrange(soi_fp,soi_rp,soi_tt,ncol=1)
dev.off()

### CDB ###

p1 <- subset(p,roi%in%c("np1_c","adj","verb","post-verb","pre-sluice","sluice","spillover1") & stype=="cdb")
p1$pos <- ifelse(p1$roi == "np1_c",1,ifelse(p1$roi == "adj",2,ifelse(p1$roi =="verb",3,ifelse(p1$roi == "post-verb",4,ifelse(p1$roi == "pre-sluice",5,ifelse(p1$roi == "sluice",6,7))))))
p1$Condition <- ifelse(p1$condition=="a","ambiguous/ellipsis",ifelse(p1$condition=="b","unambiguous/ellipsis",ifelse(p1$condition=="c","ambiguous/control","unambiguous/control")))

lbs=c("np1\nLe/s boucher/s","adj\nsale/s","verb+pronoun\nles tranche/nt,","post-verb\nmais les clients","pre-critical\n...","critical\nquand/la technique","spillover\nvu que ...")

# Plot first-pass reading times by region/condition
cdb_fp <- p1 %>% filter(firsfp==1) %>% group_by(Condition,pos) %>% dplyr::summarise(mfp=mean(firrdt),low=mean(firrdt)-1.96*std.error(firrdt),high=mean(firrdt)+1.96*std.error(firrdt)) %>% ggplot(aes(x=pos, y=mfp, color = Condition, shape=Condition)) + 
  scale_shape_manual(values=c(15,16,22,21)) +  
  theme_bw()+
  scale_linetype_manual(values=c("dashed", "dotted","solid","twodash"))+
  geom_errorbar(aes(ymin=low, ymax=high), width=.1,size=.5,position=pd) +
  geom_line(aes(linetype=Condition),size=.5,position=pd) +
  f+
  geom_point(size=2.5,position=pd,fill="white") +
  scale_x_continuous(breaks=seq(1, 7, 1),labels=lbs)+
  scale_y_continuous(breaks=seq(-5, 5, .1))+
  scale_colour_manual(values=co) +
  #coord_trans(y="log")+
  ylab("Length-corrected\nlog first-pass reading time")+
  xlab("Region")

# Plot regression-path durations by region/condition
cdb_rp <- p1 %>% filter(firsfp==1) %>% group_by(Condition,pos) %>% dplyr::summarise(mfp=mean(regrpd),low=mean(regrpd)-1.96*std.error(regrpd),high=mean(regrpd)+1.96*std.error(regrpd)) %>% ggplot(aes(x=pos, y=mfp, color = Condition, shape=Condition)) + 
  scale_shape_manual(values=c(15,16,22,21)) +  
  theme_bw()+
  scale_linetype_manual(values=c("dashed", "dotted","solid","twodash"))+
  geom_errorbar(aes(ymin=low, ymax=high), width=.1,size=.5,position=pd) +
  geom_line(aes(linetype=Condition),size=.5,position=pd) +
  f+
  geom_point(size=2.5,position=pd,fill="white") +
  scale_x_continuous(breaks=seq(1, 7, 1),labels=lbs)+
  scale_y_continuous(breaks=seq(-5, 5, .1))+
  scale_colour_manual(values=co) +
  #coord_trans(y="log")+
  ylab("Length-corrected\nlog regression-path duration")+
  xlab("Region")

# Plot total reading time by region/condition
cdb_tt <- p1 %>% group_by(Condition,pos) %>% dplyr::summarise(mfp=mean(dwellt),low=mean(dwellt)-1.96*std.error(dwellt),high=mean(dwellt)+1.96*std.error(dwellt)) %>% ggplot(aes(x=pos, y=mfp, color = Condition, shape=Condition)) + 
  scale_shape_manual(values=c(15,16,22,21)) +  
  theme_bw()+
  scale_linetype_manual(values=c("dashed", "dotted","solid","twodash"))+
  geom_errorbar(aes(ymin=low, ymax=high), width=.1,size=.5,position=pd) +
  geom_line(aes(linetype=Condition),size=.5,position=pd) +
  f+
  geom_point(size=2.5,position=pd,fill="white") +
  scale_x_continuous(breaks=seq(1, 7, 1),labels=lbs)+
  scale_y_continuous(breaks=seq(-5, 5, .1))+
  scale_colour_manual(values=co) +
  #coord_trans(y="log")+
  ylab("Length-corrected\nlog total reading time")+
  xlab("Region")

tiff("cdb-grid.tif",height=8.75,width=7.5,units='in',res=300,compression="lzw",family="Times New Roman")
grid.arrange(cdb_fp,cdb_rp,cdb_tt,ncol=1)
dev.off()
