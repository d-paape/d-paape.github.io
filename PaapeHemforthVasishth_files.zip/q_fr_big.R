library(plyr)
library(lme4)
library(dplyr)
library(plotrix)
library(rstan)
library(rstanarm)

smry <- function(model,no){
	summ <- summary(model,digits=3,probs=c(0.025,0.975))
	df <- head(data.frame(summ),no)
	print(round(df,3))
	print(sapply(data.frame(model)[0:nrow(df)],function(x) round(mean(x > 0),2)))
}

# START PREPROCESSING

qdata <- read.table("data_fr_q.txt")

ddply(.data=na.omit(qdata),.(stype),summarize,acc=mean(as.numeric(as.character(BUTTON_ACCURACY))))

params<-c("alpha","beta","sigma_u","sigma_w","sigma_x","sigma_y")

if (FALSE) {
dat_rt <- list(subject=as.integer(factor(qdata$subj)),
               itemsoi=as.integer(qdata$item_num),
               itemrrc=as.integer(qdata$item_num),
               itemcdb=as.integer(qdata$item_num),
               rt=qdata$BUTTON_RT,       
               amb=qdata$amb,
               el=qdata$el,
               stype=qdata$stype_num,
               N_obs = nrow(qdata),
               I = length(unique(qdata$subj)),
               J = 20,
               K = 16,
               L = 20
               )
                                 
fr_big_qr <- stan(file="fr_big_qr.stan",
                control=list(adapt_delta=.99),
                init=0,
                iter=4000,
                chains=4,
                cores=4,
                warmup=2000,
                refresh=100,
                data=dat_rt,
                pars=params)
                
print(round(data.frame(summary(fr_big_qr,digits=3,probs=c(0.025,0.975))),3))
save(fr_big_qr,file="fr_big_qr.Rda")
}

qdata<-filter(qdata,!is.na(qdata$BUTTON_ACCURACY))

dat_acc <- list(subject=as.integer(factor(qdata$subj)),
               itemsoi=as.integer(qdata$item_num),
               itemrrc=as.integer(qdata$item_num),
               itemcdb=as.integer(qdata$item_num),
               acc=as.numeric(as.character(qdata$BUTTON_ACCURACY)),       
               amb=qdata$amb,
               el=qdata$el,
               logrt=scale(log(qdata$BUTTON_RT),scale=F)[,1],
               stype=qdata$stype_num,
               N_obs = nrow(qdata),
               I = length(unique(qdata$subj)),
               J = 20,
               K = 16,
               L = 20
               )
                                 
fr_big_qa <- stan(file="fr_big_qa.stan",
                control=list(adapt_delta=.99),
                init=0,
                iter=4000,
                chains=4,
                cores=4,
                warmup=2000,
                refresh=100,
                data=dat_acc,
                pars=params)
                
print(round(data.frame(summary(fr_big_qa,digits=3,probs=c(0.025,0.975))),3))
save(fr_big_qa,file="fr_big_qa.Rda")

