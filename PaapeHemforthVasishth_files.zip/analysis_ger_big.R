library(data.table)
library(dplyr)
library(stringr)
library(plyr)
library(plotrix)
library(MASS)
library(rstan)
library(rstanarm)

smry <- function(model,no){
	summ <- summary(model,digits=3,probs=c(0.025,0.975))
	df <- head(data.frame(summ),no)
	print(round(df,3))
	print(sapply(data.frame(model)[0:nrow(df)],function(x) round(mean(x > 0),2)))
}

data <- read.table("data_ger.txt")
qdat <- read.table("data_ger_q.txt")

mean(qdat$acc)
qdat$gp <- ifelse(qdat$item%in%c(3,6,7,8,16,19,21,22,23,25,28,31),1,-1)
qdat$wh <- ifelse(qdat$item%in%c(2,4,10,11,13,15,20,26),1,-1)

data <- subset(data,roi%in%c("np1","aux","np2","adj","vp","wh-1","wh","wh+1"))

params<-c("sigma","alpha","beta","sigma_u","sigma_w")

# Only consider ROIs where first fixation is progressive for FPRT and RPD

d1 <- subset(data, firrdt > 0 & firsfp==1)
d2 <- subset(data, regrpd > 0 & firsfp==1)

dat_frt <- list(subject=as.integer(factor(d1$subj)),
               item=as.integer(d1$item),
               dv=d1$firrdt,       
               order=d1$order,
               gender=d1$gender,
               length=scale(log(d1$length),scale=F)[,1],
               roi=d1$roi_num,
               N_obs = nrow(d1),
               I = length(unique(d1$subj)),
               J = length(unique(d1$item))
               )
                                 
big_frt_ger <- stan(file="ger_big.stan",
                control=list(adapt_delta=.99),
                init=0,
                iter=4000,
                chains=4,
                cores=4,
                warmup=2000,
                refresh=100,
                data=dat_frt,
                pars=params)       
                
                
print(round(data.frame(summary(big_frt_ger,digits=3,probs=c(0.025,0.975))),3))
save(big_frt_ger,file="big_frt_ger.Rda")

dat_rpd <- list(subject=as.integer(factor(d2$subj)),
               item=as.integer(d2$item),
               dv=d2$regrpd,       
               order=d2$order,
               gender=d2$gender,
               length=scale(log(d2$length),scale=F)[,1],
               roi=d2$roi_num,
               N_obs = nrow(d2),
               I = length(unique(d2$subj)),
               J = length(unique(d2$item))
               )
               
                                 
big_rpd_ger <- stan(file="ger_big.stan",
                control=list(adapt_delta=.99),
                init=0,
                iter=4000,
                chains=4,
                cores=4,
                warmup=2000,
                refresh=100,
                data=dat_rpd,
                pars=params)
                
print(round(data.frame(summary(big_rpd_ger,digits=3,probs=c(0.025,0.975))),3))
save(big_rpd_ger,file="big_rpd_ger.Rda")

dat_trt <- list(subject=as.integer(factor(data$subj)),
               item=as.integer(data$item),
               dv=data$dwellt,       
               order=data$order,
               gender=data$gender,
               length=scale(log(data$length),scale=F)[,1],
               roi=data$roi_num,
               N_obs = nrow(data),
               I = length(unique(data$subj)),
               J = length(unique(data$item))
               )    
                                 
big_trt_ger <- stan(file="ger_big.stan",
                control=list(adapt_delta=.99),
                init=0,
                iter=4000,
                chains=4,
                cores=4,
                warmup=2000,
                refresh=100,
                data=dat_trt,
                pars=params)
                
print(round(data.frame(summary(big_trt_ger,digits=3,probs=c(0.025,0.975))),3))
save(big_trt_ger,file="big_trt_ger.Rda")

# Extra analysis for trials where answer is wrong and probe didn't target antecedent argument structure

dq <- merge(data,dplyr::select(qdat,subj,item,acc,gp),by.x=c("subj","item"),by.y=c("subj","item"))
test <- droplevels(filter(dq, firrdt > 0 & firsfp==1 & roi == "wh+1")) %>% filter(acc==0 & gp==-1)
smry(frt_ger_wh1_noacc <- stan_lmer(log(firrdt)~gender*order+scale(log(length),scale=F)+(gender*order+scale(log(length),scale=F)|subj)+(gender*order|item),test,cores=4,iter=4000,adapt_delta=0.999,refresh=-1,prior=cauchy(0,2.5),prior_intercept=cauchy(0,2.5),prior_covariance=decov(regularization=2)),5)
save(frt_ger_wh1_noacc,file="frt_ger_wh1_noacc.Rda")

test <- droplevels(filter(d1, roi == "np2"))
smry(frt_ger_np2_nested <- stan_lmer(log(firrdt)~c1+c2+gender+scale(log(length),scale=F)+(c1+c2+gender+scale(log(length),scale=F)|subj)+(c1+c2+gender|item),test,cores=4,iter=4000,adapt_delta=0.999,refresh=-1,prior=cauchy(0,2.5),prior_intercept=cauchy(0,2.5),prior_covariance=decov(regularization=2)),5)
save(frt_ger_np2_nested,file="frt_ger_np2_nested.Rda")

test <- droplevels(filter(d1, roi == "wh+1"))
smry(frt_ger_wh1_nested <- stan_lmer(log(firrdt)~c1+c2+gender+scale(log(length),scale=F)+(c1+c2+gender+scale(log(length),scale=F)|subj)+(c1+c2+gender|item),test,cores=4,iter=4000,adapt_delta=0.999,refresh=-1,prior=cauchy(0,2.5),prior_intercept=cauchy(0,2.5),prior_covariance=decov(regularization=2)),5)
save(frt_ger_wh1_nested,file="frt_ger_wh1_nested.Rda")

test <- droplevels(filter(d2, roi == "np2"))
smry(rpd_ger_np2_nested <- stan_lmer(log(regrpd)~c1+c2+gender+scale(log(length),scale=F)+(c1+c2+gender|subj)+(c1+c2+gender|item),test,cores=4,iter=4000,adapt_delta=0.999,refresh=-1,prior=cauchy(0,2.5),prior_intercept=cauchy(0,2.5),prior_covariance=decov(regularization=2)),5)
save(rpd_ger_np2_nested,file="rpd_ger_np2_nested.Rda")

library(em2)

# Fixations made before and after fixating the ellipsis

new2<-read.table("data_ger_after_ellipsis.txt")
new3 <- read.table("data_ger_before_ellipsis.txt")

test<-subset(new2,id==1)
smry(reread_ger_np1 <- stan_glmer(reread~gender*order+scale(log(length),scale=F)+(gender*order+scale(log(length),scale=F)|subj)+(gender*order|item),family=binomial(link="logit"),test,cores=4,iter=4000,adapt_delta=0.999,refresh=-1,prior=cauchy(0,2.5),prior_intercept=cauchy(0,2.5),prior_covariance=decov(regularization=2)),9)
save(reread_ger_np1,file="reread_ger_np1.Rda")

test<-subset(new2,id==2)
smry(reread_ger_aux <- stan_glmer(reread~gender*order+scale(log(length),scale=F)+(gender*order+scale(log(length),scale=F)|subj)+(gender*order|item),family=binomial(link="logit"),test,cores=4,iter=4000,adapt_delta=0.999,refresh=-1,prior=cauchy(0,2.5),prior_intercept=cauchy(0,2.5),prior_covariance=decov(regularization=2)),9)
save(reread_ger_aux,file="reread_ger_aux.Rda")

test<-subset(new2,id==3)
smry(reread_ger_np2 <- stan_glmer(reread~gender*order+scale(log(length),scale=F)+(gender*order+scale(log(length),scale=F)|subj)+(gender*order|item),family=binomial(link="logit"),test,cores=4,iter=4000,adapt_delta=0.999,refresh=-1,prior=cauchy(0,2.5),prior_intercept=cauchy(0,2.5),prior_covariance=decov(regularization=2)),9)
save(reread_ger_np2,file="reread_ger_np2.Rda")

test<-subset(new2,id==1 & TFT>20)
smry(rrt_ger_np1 <- stan_lmer(log(TFT)~gender*order+scale(log(length),scale=F)+(gender*order+scale(log(length),scale=F)|subj)+(gender*order|item),test,cores=4,iter=4000,adapt_delta=0.999,refresh=-1,prior=cauchy(0,2.5),prior_intercept=cauchy(0,2.5),prior_covariance=decov(regularization=2)),5)
save(rrt_ger_np1,file="rrt_ger_np1.Rda")

test<-subset(new2,id==2 & TFT>20)
smry(rrt_ger_aux <- stan_lmer(log(TFT)~gender*order+scale(log(length),scale=F)+(gender*order+scale(log(length),scale=F)|subj)+(gender*order|item),test,cores=4,iter=4000,adapt_delta=0.999,refresh=-1,prior=cauchy(0,2.5),prior_intercept=cauchy(0,2.5),prior_covariance=decov(regularization=2)),5)
save(rrt_ger_aux,file="rrt_ger_aux.Rda")

test<-subset(new2,id==3 & TFT>20)
smry(rrt_ger_np2 <- stan_lmer(log(TFT)~gender*order+scale(log(length),scale=F)+(gender*order+scale(log(length),scale=F)|subj)+(gender*order|item),test,cores=4,iter=4000,adapt_delta=0.999,refresh=-1,prior=cauchy(0,2.5),prior_intercept=cauchy(0,2.5),prior_covariance=decov(regularization=2)),5)
save(rrt_ger_np2,file="rrt_ger_np2.Rda")

test<-subset(new3,id==1 & TFT>20)
smry(before_ger_np1 <- stan_lmer(log(TFT)~gender*order+scale(log(length),scale=F)+(gender*order+scale(log(length),scale=F)|subj)+(gender*order|item),test,cores=4,iter=4000,adapt_delta=0.999,refresh=-1,prior=cauchy(0,2.5),prior_intercept=cauchy(0,2.5),prior_covariance=decov(regularization=2)),5)
save(before_ger_np1,file="before_ger_np1.Rda")

test<-subset(new3,id==2 & TFT>20)
smry(before_ger_aux <- stan_lmer(log(TFT)~gender*order+scale(log(length),scale=F)+(gender*order+scale(log(length),scale=F)|subj)+(gender*order|item),test,cores=4,iter=4000,adapt_delta=0.999,refresh=-1,prior=cauchy(0,2.5),prior_intercept=cauchy(0,2.5),prior_covariance=decov(regularization=2)),5)
save(before_ger_aux,file="before_ger_aux.Rda")

test<-subset(new3,id==3 & TFT>20)
smry(before_ger_np2 <- stan_lmer(log(TFT)~gender*order+scale(log(length),scale=F)+(gender*order+scale(log(length),scale=F)|subj)+(gender*order|item),test,cores=4,iter=4000,adapt_delta=0.999,refresh=-1,prior=cauchy(0,2.5),prior_intercept=cauchy(0,2.5),prior_covariance=decov(regularization=2)),5)
save(before_ger_np2,file="before_ger_np2.Rda")

test <- droplevels(filter(data, roi == "wh+1"))
smry(trt_ger_wh1_nested <- stan_lmer(log(dwellt)~c1+c2+gender+scale(log(length),scale=F)+(c1+c2+gender+scale(log(length),scale=F)|subj)+(c1+c2+gender|item),test,cores=4,iter=4000,adapt_delta=0.999,refresh=-1,prior=cauchy(0,2.5),prior_intercept=cauchy(0,2.5),prior_covariance=decov(regularization=2)),5)
save(trt_ger_wh1_nested,file="trt_ger_wh1_nested.Rda")
