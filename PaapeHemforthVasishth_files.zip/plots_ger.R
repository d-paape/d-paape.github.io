# Code to generate plots for Experiment 2

library(data.table)
library(dplyr)
library(stringr)
library(plotrix)

data <- read.table("data_ger.txt")

library(ggplot2)
library(gridExtra)
library(R.utils)

pd <- position_dodge(.3)
co<- c("#FF33CC", "#0099FF","#006600","#FF6600")

f <- theme(axis.title.x = element_text(face="bold", size=9),
           axis.text.x = element_text(color="black",size=8),
           axis.title.y = element_text(face="bold", size=9),
           axis.text.y = element_text(color="black",size=8),
           legend.title = element_text(face="bold", size=9),
           plot.title = element_text(face="bold",lineheight=.8,size=9),
           legend.text = element_text(color="black",size=8),
           legend.position="top")

p1 <- subset(data,roi%in%c("np1","aux","np2","adj","vp","wh-1","wh","wh+1") & firrdt > 0)
p1$pos <- ifelse(p1$roi == "np1",1,ifelse(p1$roi == "aux",2,ifelse(p1$roi =="np2",3,ifelse(p1$roi == "adj",4,ifelse(p1$roi == "vp",5,ifelse(p1$roi == "wh-1",6,ifelse(p1$roi == "wh",7,8)))))))
p1$Condition <- ifelse(p1$condition=="a","ambiguous/OVS",ifelse(p1$condition=="b","ambiguous/SVO",ifelse(p1$condition=="c","unambiguous/OVS","unambiguous/SVO")))
p2 <- subset(p1,regrpd>0)

p1$firrdt <- residuals(lm(log(firrdt)~scale(log(length),scale=F),p1))
p2$regrpd <- residuals(lm(log(regrpd)~scale(log(length),scale=F),p2))
p1$dwellt <- residuals(lm(log(dwellt)~scale(log(length),scale=F),p1))

lbs=c("np1\nA sympathizer ...","aux\nhad","np2\nthe rebels","adj\naccording to ...","vp\n... supported","wh-1\n...","wh\nhow,","wh+1\nso greatly ...")

p1 %>% filter(pos==8) %>% group_by(Condition,pos) %>% dplyr::summarise(mfp=mean(firrdt),low=mean(firrdt)-1.96*std.error(firrdt),high=mean(firrdt)+1.96*std.error(firrdt))

# Plot first-pass reading times by region/condition
ger_fp <- p1 %>% group_by(Condition,pos) %>% dplyr::summarise(mfp=mean(firrdt),low=mean(firrdt)-1.96*std.error(firrdt),high=mean(firrdt)+1.96*std.error(firrdt)) %>% ggplot(aes(x=pos, y=mfp, color = Condition, shape=Condition)) + 
  scale_shape_manual(values=c(15,16,22,21)) + 
  theme_bw()+
  scale_linetype_manual(values=c("dashed", "dotted","solid","twodash"))+
  geom_errorbar(aes(ymin=low, ymax=high), width=.1,size=.5,position=pd) +
  geom_line(aes(linetype=Condition),size=.5,position=pd) +
  f+
  geom_point(size=2.5,position=pd,fill="white") +
  scale_x_continuous(breaks=seq(1, 8, 1),labels=lbs)+
  scale_y_continuous(breaks=seq(-5,5, .1))+
  scale_colour_manual(values=co) +
  #coord_trans(y="log")+
  ylab("Length-corrected\nlog first-pass reading time")+
  xlab("Region")

# Plot regression-path durations by region/condition
ger_rp <- p2 %>% group_by(Condition,pos) %>% dplyr::summarise(mfp=mean(regrpd),low=mean(regrpd)-1.96*std.error(regrpd),high=mean(regrpd)+1.96*std.error(regrpd)) %>% ggplot(aes(x=pos, y=mfp, color = Condition, shape=Condition)) + 
  scale_shape_manual(values=c(15,16,22,21)) + 
  theme_bw()+
  scale_linetype_manual(values=c("dashed", "dotted","solid","twodash"))+
  geom_errorbar(aes(ymin=low, ymax=high), width=.1,size=.5,position=pd) +
  geom_line(aes(linetype=Condition),size=.5,position=pd) +
  f+
  geom_point(size=2.5,position=pd,fill="white") +
  scale_x_continuous(breaks=seq(1, 8, 1),labels=lbs)+
  scale_y_continuous(breaks=seq(-5, 5, .1))+
  scale_colour_manual(values=co) +
  #coord_trans(y="log")+
  ylab("Length-corrected\nlog regression-path duration")+
  xlab("Region")

# Plot total fixation times by region/condition
ger_tt <- p1 %>% group_by(Condition,pos) %>% dplyr::summarise(mfp=mean(dwellt),low=mean(dwellt)-1.96*std.error(dwellt),high=mean(dwellt)+1.96*std.error(dwellt)) %>% ggplot(aes(x=pos, y=mfp, color = Condition, shape=Condition)) + 
  scale_shape_manual(values=c(15,16,22,21)) +     
  theme_bw()+
  scale_linetype_manual(values=c("dashed", "dotted","solid","twodash"))+
  geom_errorbar(aes(ymin=low, ymax=high), width=.1,size=.5,position=pd) +
  geom_line(aes(linetype=Condition),size=.5,position=pd) +
  f+
  geom_point(size=2.5,position=pd,fill="white") +
  scale_x_continuous(breaks=seq(1, 8, 1),labels=lbs)+
  scale_y_continuous(breaks=seq(-5, 5, .1))+
  scale_colour_manual(values=co) +
  #coord_trans(y="log")+
  ylab("Length-corrected\nlog total reading time")+
  xlab("Region")

tiff("ger-grid.tif",height=8.75,width=7.5,units='in',res=300,compression="lzw",family="Times New Roman")
grid.arrange(ger_fp,ger_rp,ger_tt,ncol=1)
dev.off()
