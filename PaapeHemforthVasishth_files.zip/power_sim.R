library(dplyr)
library(lme4)
library(parallel)

dm = function(i){
  cat("o ")
  mc<-lmer(simrt~el*amb+scale(log(length),scale=F)+(el*amb|item)+(el*amb|subj),data=t[[i]])
}

dm2 = function(i){
  cat("o ")
  mc<-lmer(simrt~gender*order+scale(log(length),scale=F)+(gender*order|item)+(gender*order|subj),data=t[[i]])
}

adata <- read.table("data_fr.txt")
adata$subj <- gsub("s","",adata$subj)
adata2 <- read.table("data_ger.txt")
pv1 <- c(0)
pv2 <- c(0)
pv3 <- c(0)
pv4 <- c(0)

if (FALSE) {

data <- filter(adata,stype=="cdb"&roi=="sluice")
td2 <- data[,c(1,3,22,27,28,33)]
td3<- filter(td2,as.numeric(subj)<=22)
td3$subj<-as.character(as.numeric(td3$subj)+100)
td4<-filter(rbind(td2,td3),subj!=unique(td2$subj)[41])
summary(mt1 <- lmer(log(dwellt)~el*amb+scale(log(length),scale=F)+(el*amb|item)+(el*amb|subj),data))
res1 <- mt1@devcomp$cmp[10]

for (n in c(21,41,61)){
  if (n==21) {dt<-td3} else if (n==41) {dt<-td2} else {dt<-td4}
for (newbeta in c(mt1@beta[5]-0.02,mt1@beta[5]-0.01,mt1@beta[5],mt1@beta[5]+0.01,mt1@beta[5]+0.02)) {
    for (newsigma in c(res1-0.1,res1-0.05,res1,res1+0.05,res1+0.1)) {
    mt1@devcomp$cmp[10] <- newsigma
    sig <- c()
    ov <- c()
	t <- replicate(1000,dt,simplify=F)
      for (l in 1:length(t)){
        suppressMessages(suppressWarnings(t[[l]]$simrt <- unlist(simulate(mt1,newdata=t[[l]],newparams=list(beta=c(mt1@beta[1],mt1@beta[2],mt1@beta[3],mt1@beta[4],newbeta),theta=mt1@theta),allow.new.levels=TRUE))))
        ov<-c(ov,sd(exp(t[[l]]$simrt)))
      }
      m.list = mclapply(1:1000, dm, mc.cores = 30)
      for (f in 1:length(m.list)){
        if (coef(summary(m.list[[f]]))[,"t value"][5]>(1.96)) {sig <- c(sig,1)} else {sig <- c(sig,0)}
      }
      pv1<-rbind(pv1,c(n,newbeta,newsigma,mean(ov),mean(sig)))
    }
    }
}

pv1<-data.frame(pv1)
colnames(pv1)<-c("n","beta","sigma","sd","power")
save(pv1,file="power1.Rda")

data <- filter(adata,stype=="rrc"&roi=="sluice")
td2 <- data[,c(1,3,22,27,28,33)]
td3<- filter(td2,as.numeric(subj)<=22)
td3$subj<-as.character(as.numeric(td3$subj)+100)
td4<-filter(rbind(td2,td3),subj!=unique(td2$subj)[41])
summary(mt2 <- lmer(log(dwellt)~el*amb+scale(log(length),scale=F)+(el*amb|item)+(el*amb|subj),data))
res2 <- mt2@devcomp$cmp[10]

for (n in c(21,41,61)){
  if (n==21) {dt<-td3} else if (n==41) {dt<-td2} else {dt<-td4}
  for (newbeta in c(mt2@beta[5]-0.02,mt2@beta[5]-0.01,mt2@beta[5],mt2@beta[5]+0.01,mt2@beta[5]+0.02)) {
    for (newsigma in c(res2-0.1,res2-0.05,res2,res2+0.05,res2+0.1)) {
      mt2@devcomp$cmp[10] <- newsigma
      sig <- c()
      ov <- c()
        t <- replicate(1000,dt,simplify=F)
        for (l in 1:length(t)){
          suppressMessages(suppressWarnings(t[[l]]$simrt <- unlist(simulate(mt2,newdata=t[[l]],newparams=list(beta=c(mt2@beta[1],mt2@beta[2],mt2@beta[3],mt2@beta[4],newbeta),theta=mt2@theta),allow.new.levels=TRUE))))
          ov<-c(ov,sd(exp(t[[l]]$simrt)))
        }
        m.list = mclapply(1:1000, dm, mc.cores = 30)
        for (f in 1:length(m.list)){
          if (abs(coef(summary(m.list[[f]]))[,"t value"][5])>(1.96)) {sig <- c(sig,1)} else {sig <- c(sig,0)}
        }
      pv2<-rbind(pv2,c(n,newbeta,newsigma,mean(ov),mean(sig)))
    }
  }
}

pv2<-data.frame(pv2)
colnames(pv2)<-c("n","beta","sigma","sd","power")
save(pv2,file="power2.Rda")

data <- filter(adata,stype=="soi"&roi=="sluice")
td2 <- data[,c(1,3,22,27,28,33)]
td3<- filter(td2,as.numeric(subj)<=22)
td3$subj<-as.character(as.numeric(td3$subj)+100)
td4<-filter(rbind(td2,td3),subj!=unique(td2$subj)[41])
summary(mt3 <- lmer(log(dwellt)~el*amb+scale(log(length),scale=F)+(el*amb|item)+(el*amb|subj),data))
res3 <- mt3@devcomp$cmp[10]

for (n in c(21,41,61)){
  if (n==21) {dt<-td3} else if (n==41) {dt<-td2} else {dt<-td4}
  for (newbeta in c(mt3@beta[5]-0.02,mt3@beta[5]-0.01,mt3@beta[5],mt3@beta[5]+0.01,mt3@beta[5]+0.02)) {
    for (newsigma in c(res3-0.1,res3-0.05,res3,res3+0.05,res3+0.1)) {
      mt3@devcomp$cmp[10] <- newsigma
      sig <- c()
      ov <- c()
      t <- replicate(1000,dt,simplify=F)
      for (l in 1:length(t)){
        suppressMessages(suppressWarnings(t[[l]]$simrt <- unlist(simulate(mt3,newdata=t[[l]],newparams=list(beta=c(mt3@beta[1],mt3@beta[2],mt3@beta[3],mt3@beta[4],newbeta),theta=mt3@theta),allow.new.levels=TRUE))))
        ov<-c(ov,sd(exp(t[[l]]$simrt)))
      }
      m.list = mclapply(1:1000, dm, mc.cores = 30)
        for (f in 1:length(m.list)){
          if (abs(coef(summary(m.list[[f]]))[,"t value"][5])>(1.96)) {sig <- c(sig,1)} else {sig <- c(sig,0)}
        }
      pv3<-rbind(pv3,c(n,newbeta,newsigma,mean(ov),mean(sig)))
      }
    }
}

pv3<-data.frame(pv3)
colnames(pv3)<-c("n","beta","sigma","sd","power")
save(pv3,file="power3.Rda")

}

data <- filter(adata2,roi=="wh+1" & firrdt>0 & firsfp==1)
td2 <- data[,c(1,6,26,32,33,34)]
td3<- filter(td2,as.numeric(subj)<=42)
td4<- filter(td2,as.numeric(subj)<=20)
td4$subj<-as.character(as.numeric(td4$subj)+100)
td4<-rbind(td4,td2)
summary(mt4 <- lmer(log(firrdt)~gender*order+scale(log(length),scale=F)+(gender*order|item)+(gender*order|subj),data))
res4 <- mt4@devcomp$cmp[10]

for (n in c(42,62,82)){
  if (n==42) {dt<-td3} else if (n==62) {dt<-td2} else {dt<-td4}
  for (newbeta in c(mt4@beta[5]-0.02,mt4@beta[5]-0.01,mt4@beta[5],mt4@beta[5]+0.01,mt4@beta[5]+0.02)) {
    for (newsigma in c(res4-0.1,res4-0.05,res4,res4+0.05,res4+0.1)) {
      mt4@devcomp$cmp[10] <- newsigma
      sig <- c()
      ov <- c()
      t <- replicate(1000,dt,simplify=F)
      for (l in 1:length(t)){
        suppressMessages(suppressWarnings(t[[l]]$simrt <- unlist(simulate(mt4,newdata=t[[l]],newparams=list(beta=c(mt4@beta[1],mt4@beta[2],mt4@beta[3],mt4@beta[4],newbeta),theta=mt4@theta),allow.new.levels=TRUE))))
        ov<-c(ov,sd(exp(t[[l]]$simrt)))
      }
      m.list = mclapply(1:1000, dm2, mc.cores = 30)
      for (f in 1:length(m.list)){
        if (coef(summary(m.list[[f]]))[,"t value"][5]<(-1.96)) {sig <- c(sig,1)} else {sig <- c(sig,0)}
      }
      pv4<-rbind(pv4,c(n,newbeta,newsigma,mean(ov),mean(sig)))
    }
  }
}

pv4<-data.frame(pv4)
colnames(pv4)<-c("n","beta","sigma","sd","power")
save(pv4,file="power4.Rda")
