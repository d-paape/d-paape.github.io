library(data.table)
library(dplyr)
library(stringr)
library(plyr)
library(plotrix)
library(rstan)
library(rstanarm)

smry <- function(model,no){
	summ <- summary(model,digits=3,probs=c(0.025,0.975))
	df <- head(data.frame(summ),no)
	print(round(df,3))
	print(sapply(data.frame(model)[0:nrow(df)],function(x) round(mean(x > 0),2)))
}

qdat <- read.table("data_ger_q.txt")

mean(qdat$acc)
qdat$gp <- ifelse(qdat$item%in%c(3,6,7,8,16,19,21,22,23,25,28,31),1,-1)
qdat$wh <- ifelse(qdat$item%in%c(2,4,10,11,13,15,20,26),1,-1)

smry(ger_qa <- stan_glmer(acc~gender*order+scale(log(rt),scale=F)+(gender*order+scale(log(rt),scale=F)|subj)+(gender*order|item),family=binomial(link="logit"),qdat,cores=4,iter=4000,adapt_delta=0.999,refresh=-1,prior=cauchy(0,2.5),prior_intercept=cauchy(0,2.5),prior_covariance=decov(regularization=2)),5)
save(ger_qa,file="ger_qa.Rda")

smry(ger_qa_gp <- stan_glmer(acc~gender*order*gp+scale(log(rt),scale=F)+(gender*order*gp+scale(log(rt),scale=F)|subj)+(gender*order|item),family=binomial(link="logit"),qdat,cores=4,iter=4000,adapt_delta=0.999,refresh=-1,prior=cauchy(0,2.5),prior_intercept=cauchy(0,2.5),prior_covariance=decov(regularization=2)),9)
save(ger_qa_gp,file="ger_qa_gp.Rda")

smry(ger_qr <- stan_lmer(log(rt)~gender*order+(gender*order|subj)+(gender*order|item),qdat,cores=4,iter=4000,adapt_delta=0.999,refresh=-1,prior=cauchy(0,2.5),prior_intercept=cauchy(0,2.5),prior_covariance=decov(regularization=2)),4)
save(ger_qr,file="ger_qr.Rda")

smry(ger_qr_gp <- stan_lmer(log(rt)~gender*order*gp+(gender*order*gp|subj)+(gender*order|item),qdat,cores=4,iter=4000,adapt_delta=0.999,refresh=-1,prior=cauchy(0,2.5),prior_intercept=cauchy(0,2.5),prior_covariance=decov(regularization=2)),9)
save(ger_qr_gp,file="ger_qr_gp.Rda")
