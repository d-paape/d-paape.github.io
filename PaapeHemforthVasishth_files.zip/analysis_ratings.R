library(rstan)

data<-read.table("data_fr_ratings.txt")

params<-c("alpha","beta","sigma_u","sigma_w","sigma_x","sigma_y")

dat1 <- list(subject=as.integer(factor(data$Subj)),
               itemsoi=as.integer(data$item_num),
               itemrrc=as.integer(data$item_num),
               itemcdb=as.integer(data$item_num),
               rating=as.integer(data$Judgment),   
               stype=as.integer(data$stype),
               cond=data$cond,
               N_obs = nrow(data),
               G = 10,
               I = length(unique(data$Subj)),
               J = 20,
               K = 16,
               L = 20
               )

ratings<- stan(file="ratings_big.stan",
                control=list(adapt_delta=.99),
                iter=4000,
                chains=4,
                init=0,
                cores=4,
                warmup=2000,
                data=dat1,
                pars=params)
                
print(round(data.frame(summary(ratings,digits=3,probs=c(0.025,0.975))),3))
save(ratings,file="ratings.Rda") 
