library(plyr)
library(lme4)
library(dplyr)
library(plotrix)
library(rstan)
library(rstanarm)

smry <- function(model,no){
	summ <- summary(model,digits=3,probs=c(0.025,0.975))
	df <- head(data.frame(summ),no)
	print(round(df,3))
	print(sapply(data.frame(model)[0:nrow(df)],function(x) round(mean(x > 0),2)))
}

data <- read.table("data_fr.txt")

# Only consider ROIs where first fixation is progressive for FPRT and RPD

data_rpd <- subset(data, firsfp == 1)
data_frt <- subset(data, firsfp == 1) 

params<-c("sigma","alpha","beta","sigma_u","sigma_w","sigma_x","sigma_y")

dat_frt <- list(subject=as.integer(factor(data_frt$subj)),
               itemsoi=as.integer(data_frt$item_num),
               itemrrc=as.integer(data_frt$item_num),
               itemcdb=as.integer(data_frt$item_num),
               dv=data_frt$firrdt,       
               amb=data_frt$amb,
               el=data_frt$el,
               length=scale(log(data_frt$length),scale=F)[,1],
               stype=data_frt$stype_num,
               roi=data_frt$roi_num,
               N_obs = nrow(data_frt),
               I = length(unique(data_frt$subj)),
               J = 20,
               K = 16,
               L = 20
               )    
                                 
big_frt <- stan(file="fr_big.stan",
                control=list(adapt_delta=.99),
                init=0,
                iter=4000,
                chains=4,
                cores=4,
                warmup=2000,
                refresh=100,
                data=dat_frt,
                pars=params)
                
print(round(data.frame(summary(big_frt,digits=3,probs=c(0.025,0.975))),3))
save(big_frt,file="big_frt.Rda")

dat_rpd <- list(subject=as.integer(factor(data_rpd$subj)),
               itemsoi=as.integer(data_rpd$item_num),
               itemrrc=as.integer(data_rpd$item_num),
               itemcdb=as.integer(data_rpd$item_num),
               dv=data_rpd$regrpd,       
               amb=data_rpd$amb,
               el=data_rpd$el,
               length=scale(log(data_rpd$length),scale=F)[,1],
               stype=data_rpd$stype_num,
               roi=data_rpd$roi_num,
               N_obs = nrow(data_rpd),
               I = length(unique(data_rpd$subj)),
               J = 20,
               K = 16,
               L = 20
               )    
                                 
big_rpd <- stan(file="fr_big.stan",
                control=list(adapt_delta=.99),
                init=0,
                iter=4000,
                chains=4,
                cores=4,
                warmup=2000,
                refresh=100,
                data=dat_rpd,
                pars=params)
                
print(round(data.frame(summary(big_rpd,digits=3,probs=c(0.025,0.975))),3))
save(big_rpd,file="big_rpd.Rda")

dat_trt <- list(subject=as.integer(factor(data$subj)),
               itemsoi=as.integer(data$item_num),
               itemrrc=as.integer(data$item_num),
               itemcdb=as.integer(data$item_num),
               dv=data$dwellt,       
               amb=data$amb,
               el=data$el,
               length=scale(log(data$length),scale=F)[,1],
               stype=data$stype_num,
               roi=data$roi_num,
               N_obs = nrow(data),
               I = length(unique(data$subj)),
               J = 20,
               K = 16,
               L = 20
               )    
                                 
big_trt <- stan(file="fr_big.stan",
                control=list(adapt_delta=.99),
                init=0,
                iter=4000,
                chains=4,
                cores=4,
                warmup=2000,
                refresh=100,
                data=dat_trt,
                pars=params)
                
print(round(data.frame(summary(big_trt,digits=3,probs=c(0.025,0.975))),3))
save(big_trt,file="big_trt.Rda")

# For nested contrasts, c1 is ambiguity sum-coded within elision conditions, c2 is ambiguity sum-coded within control conditions

test <- subset(data_rpd, roi=="adj" & stype =="cdb")
smry(rpd_cdb_adj_nested <- stan_lmer(log(regrpd) ~ c1+c2+el+scale(log(length),scale=F)+(c1+c2+el|item)+(c1+c2+el+scale(log(length),scale=F)|subj), test,cores=4,iter=4000,adapt_delta=0.999,refresh=-1,prior=cauchy(0,2.5),prior_intercept=cauchy(0,2.5),prior_covariance=decov(regularization=2)),5)
save(rpd_cdb_adj_nested,file="rpd_cdb_adj_nested.Rda")

# Read in corpus data and calculate (log) ratio as bias

biases <- read.table("biases",header=T)
mean(biases$vcount/biases$acount)
biases$lr <- log(biases$vcount/biases$acount)
mean(biases$lr)

test <- subset(data_frt, roi=="adj" & stype =="cdb")
test <- merge(test,biases,by.x=c("item"),by.y=c("item"))
smry(frt_cdb_adj_bias <- stan_lmer(log(firrdt) ~ el*amb*scale(lr,scale=F)+scale(log(length),scale=F)+(amb*el|item)+(amb*el*scale(lr,scale=F)+scale(log(length),scale=F)|subj), test,cores=4,iter=4000,adapt_delta=0.999,refresh=-1,prior=cauchy(0,2.5),prior_intercept=cauchy(0,2.5),prior_covariance=decov(regularization=2)),9)
save(frt_cdb_adj_bias,file="frt_cdb_adj_bias.Rda")

test <- subset(data_rpd, roi=="adj" & stype =="cdb")
test <- merge(test,biases,by.x=c("item"),by.y=c("item"))
smry(rpd_cdb_adj_bias <- stan_lmer(log(regrpd) ~ el*amb*scale(lr,scale=F)+scale(log(length),scale=F)+(amb*el|item)+(amb*el*scale(lr,scale=F)+scale(log(length),scale=F)|subj), test,cores=4,iter=4000,adapt_delta=0.999,refresh=-1,prior=cauchy(0,2.5),prior_intercept=cauchy(0,2.5),prior_covariance=decov(regularization=2)),9)
save(rpd_cdb_adj_bias,file="rpd_cdb_adj_bias.Rda")

test <- subset(data, roi=="adj" & stype =="cdb")
test <- merge(test,biases,by.x=c("item"),by.y=c("item"))
smry(trt_cdb_adj_bias <- stan_lmer(log(dwellt) ~ el*amb*scale(lr,scale=F)+scale(log(length),scale=F)+(amb*el|item)+(amb*el*scale(lr,scale=F)+scale(log(length),scale=F)|subj), test,cores=4,iter=4000,adapt_delta=0.999,refresh=-1,prior=cauchy(0,2.5),prior_intercept=cauchy(0,2.5),prior_covariance=decov(regularization=2)),9)
save(trt_cdb_adj_bias,file="trt_cdb_adj_bias.Rda")
smry(trt_cdb_adj_bias_nested <- stan_lmer(log(dwellt) ~ (c1+c2+el)*scale(lr,scale=F)+scale(log(length),scale=F)+(c1+c2+el|item)+((c1+c2+el)*scale(lr,scale=F)+scale(log(length),scale=F)|subj), test,cores=4,iter=4000,adapt_delta=0.999,refresh=-1,prior=cauchy(0,2.5),prior_intercept=cauchy(0,2.5),prior_covariance=decov(regularization=2)),9)
save(trt_cdb_adj_bias_nested,file="trt_cdb_adj_bias_nested.Rda")

t1 <- subset(test,amb==-1)
smry(trt_cdb_adj_bias_nested1 <- stan_lmer(log(dwellt) ~ el*scale(lr,scale=F)+scale(log(length),scale=F)+(el|item)+(el*scale(lr,scale=F)+scale(log(length),scale=F)|subj), t1,cores=4,iter=4000,adapt_delta=0.999,refresh=-1,prior=cauchy(0,2.5),prior_intercept=cauchy(0,2.5),prior_covariance=decov(regularization=2)),9)
save(trt_cdb_adj_bias_nested1,file="trt_cdb_adj_bias_nested1.Rda")

t2 <- subset(test,amb==1)
smry(trt_cdb_adj_bias_nested2 <- stan_lmer(log(dwellt) ~ el*scale(lr,scale=F)+scale(log(length),scale=F)+(el|item)+(el*scale(lr,scale=F)+scale(log(length),scale=F)|subj), t2,cores=4,iter=4000,adapt_delta=0.999,refresh=-1,prior=cauchy(0,2.5),prior_intercept=cauchy(0,2.5),prior_covariance=decov(regularization=2)),9)
save(trt_cdb_adj_bias_nested2,file="trt_cdb_adj_bias_nested2.Rda")

test <- subset(data_rpd, roi=="pre-sluice" & stype =="rrc")
smry(rpd_rrc_pre_sluice_nested <- stan_lmer(log(regrpd) ~ c1+c2+el+scale(log(length),scale=F)+(c1+c2+el|item)+(c1+c2+el+scale(log(length),scale=F)|subj), test,cores=4,iter=4000,adapt_delta=0.999,refresh=-1,prior=cauchy(0,2.5),prior_intercept=cauchy(0,2.5),prior_covariance=decov(regularization=2)),9)
save(rpd_rrc_pre_sluice_nested,file="rpd_rrc_pre_sluice_nested.Rda")

test <- droplevels(subset(data, roi == "adj" & stype == "cdb"))
smry(trt_cdb_adj_nested <- stan_lmer(log(dwellt) ~ c1+c2+el+scale(log(length),scale=F)+(c1+c2+el|item)+(c1+c2+el+scale(log(length),scale=F)|subj), test,cores=4,iter=4000,adapt_delta=0.999,refresh=-1,prior=cauchy(0,2.5),prior_intercept=cauchy(0,2.5),prior_covariance=decov(regularization=2)),5)
save(trt_cdb_adj_nested,file="trt_cdb_adj_nested.Rda")
test <- droplevels(subset(data, roi == "verb" & stype == "cdb"))
smry(trt_cdb_verb_nested <- stan_lmer(log(dwellt) ~ c1+c2+el+scale(log(length),scale=F)+(c1+c2+el|item)+(c1+c2+el+scale(log(length),scale=F)|subj), test,cores=4,iter=4000,adapt_delta=0.999,refresh=-1,prior=cauchy(0,2.5),prior_intercept=cauchy(0,2.5),prior_covariance=decov(regularization=2)),5)
save(trt_cdb_verb_nested,file="trt_cdb_verb_nested.Rda")
test <- droplevels(subset(data, roi == "sluice" & stype == "cdb"))
smry(trt_cdb_sluice_nested <- stan_lmer(log(dwellt) ~ c1+c2+el+scale(log(length),scale=F)+(c1+c2+el|item)+(c1+c2+el+scale(log(length),scale=F)|subj), test,cores=4,iter=4000,adapt_delta=0.999,refresh=-1,prior=cauchy(0,2.5),prior_intercept=cauchy(0,2.5),prior_covariance=decov(regularization=2)),5)
save(trt_cdb_sluice_nested,file="trt_cdb_sluice_nested.Rda")

# Fixations made before and after fixating the ellipsis for exploratory analyses

library(em2)

new<-read.table("data_fr_after_ellipsis.txt")
new2<-read.table("data_fr_before_ellipsis.txt")

new$reread<-as.numeric(as.character(new$reread))

test <- subset(new, roi=="np1_c" & stype=="cdb")
smry(reread_cdb_np1_c <- stan_glmer(reread ~ el*amb+scale(log(length),scale=F)+(amb*el|item)+(amb*el+scale(log(length),scale=F)|subj), test,family=binomial(link="logit"),cores=4,iter=4000,adapt_delta=0.999,refresh=-1,prior=cauchy(0,2.5),prior_intercept=cauchy(0,2.5),prior_covariance=decov(regularization=2)),9)
save(reread_cdb_np1_c,file="reread_cdb_np1_c.Rda")
smry(reread_cdb_np1_c_nested <- stan_glmer(reread ~ c1+c2+el+scale(log(length),scale=F)+(c1+c2+el|item)+(c1+c2+el+scale(log(length),scale=F)|subj), test,family=binomial(link="logit"),cores=4,iter=4000,adapt_delta=0.999,refresh=-1,prior=cauchy(0,2.5),prior_intercept=cauchy(0,2.5),prior_covariance=decov(regularization=2)),9)
save(reread_cdb_np1_c_nested,file="reread_cdb_np1_c_nested.Rda")

test <- subset(new, roi=="adj" & stype=="cdb")
smry(reread_cdb_adj <- stan_glmer(reread ~ el*amb+scale(log(length),scale=F)+(amb*el|item)+(amb*el+scale(log(length),scale=F)|subj), test,family=binomial(link="logit"),cores=4,iter=4000,adapt_delta=0.999,refresh=-1,prior=cauchy(0,2.5),prior_intercept=cauchy(0,2.5),prior_covariance=decov(regularization=2)),9)
save(reread_cdb_adj,file="reread_cdb_adj.Rda")
smry(reread_cdb_adj_nested <- stan_glmer(reread ~ c1+c2+el+scale(log(length),scale=F)+(c1+c2+el|item)+(c1+c2+el+scale(log(length),scale=F)|subj), test,family=binomial(link="logit"),cores=4,iter=4000,adapt_delta=0.999,refresh=-1,prior=cauchy(0,2.5),prior_intercept=cauchy(0,2.5),prior_covariance=decov(regularization=2)),9)
save(reread_cdb_adj_nested,file="reread_cdb_adj_nested.Rda")

test <- subset(new, roi=="verb" & stype=="cdb")
smry(reread_cdb_verb <- stan_glmer(reread ~ el*amb+scale(log(length),scale=F)+(amb*el|item)+(amb*el+scale(log(length),scale=F)|subj), test,family=binomial(link="logit"),cores=4,iter=4000,adapt_delta=0.999,refresh=-1,prior=cauchy(0,2.5),prior_intercept=cauchy(0,2.5),prior_covariance=decov(regularization=2)),9)
save(reread_cdb_verb,file="reread_cdb_verb.Rda")
smry(reread_cdb_verb_nested <- stan_glmer(reread ~ c1+c2+el+scale(log(length),scale=F)+(c1+c2+el|item)+(c1+c2+el+scale(log(length),scale=F)|subj), test,family=binomial(link="logit"),cores=4,iter=4000,adapt_delta=0.999,refresh=-1,prior=cauchy(0,2.5),prior_intercept=cauchy(0,2.5),prior_covariance=decov(regularization=2)),9)
save(reread_cdb_verb_nested,file="reread_cdb_verb_nested.Rda")

test <- subset(new2, roi=="np1_c" & stype=="cdb" & TFT> 20)
smry(trt_before_np1_c <- stan_lmer(log(TFT) ~ el*amb+scale(log(length),scale=F)+(amb*el|item)+(amb*el+scale(log(length),scale=F)|subj),test,cores=4,iter=4000,adapt_delta=0.999,refresh=-1,prior=cauchy(0,2.5),prior_intercept=cauchy(0,2.5),prior_covariance=decov(regularization=2)),9)
save(trt_before_np1_c,file="trt_before_cdb_np1_c.Rda")

test <- subset(new2, roi=="adj" & stype=="cdb" & TFT> 20)
smry(trt_before_adj <- stan_lmer(log(TFT) ~ el*amb+scale(log(length),scale=F)+(amb*el|item)+(amb*el+scale(log(length),scale=F)|subj),test,cores=4,iter=4000,adapt_delta=0.999,refresh=-1,prior=cauchy(0,2.5),prior_intercept=cauchy(0,2.5),prior_covariance=decov(regularization=2)),9)
save(trt_before_adj,file="trt_before_cdb_adj.Rda")

test <- subset(new2, roi=="verb" & stype=="cdb" & TFT> 20)
smry(trt_before_verb <- stan_lmer(log(TFT) ~ el*amb+scale(log(length),scale=F)+(amb*el|item)+(amb*el+scale(log(length),scale=F)|subj),test,cores=4,iter=4000,adapt_delta=0.999,refresh=-1,prior=cauchy(0,2.5),prior_intercept=cauchy(0,2.5),prior_covariance=decov(regularization=2)),9)
save(trt_before_verb,file="trt_before_cdb_verb.Rda")

test <- subset(new2, roi=="adj" & stype=="cdb" & TFT> 20)
test <- merge(test,biases,by.x=c("item"),by.y=c("item"))

smry(trt_before_cdb_adj_bias <- stan_lmer(log(TFT) ~ el*amb*scale(lr,scale=F)+scale(log(length),scale=F)+(amb*el|item)+(amb*el*scale(lr,scale=F)+scale(log(length),scale=F)|subj),test,cores=4,iter=4000,adapt_delta=0.999,refresh=-1,prior=cauchy(0,2.5),prior_intercept=cauchy(0,2.5),prior_covariance=decov(regularization=2)),9)
save(trt_before_cdb_adj_bias,file="trt_before_cdb_adj_bias.Rda")

test <- subset(test,amb==-1)
smry(trt_before_cdb_adj_nested1 <- stan_lmer(log(TFT) ~ el*scale(lr,scale=F)+scale(log(length),scale=F)+(el|item)+(el*scale(lr,scale=F)+scale(log(length),scale=F)|subj), test,cores=4,iter=4000,adapt_delta=0.999,refresh=-1,prior=cauchy(0,2.5),prior_intercept=cauchy(0,2.5),prior_covariance=decov(regularization=2)),9)
save(trt_before_cdb_adj_nested1,file="trt_before_cdb_adj_nested1.Rda")

test <- subset(test,amb==1)
smry(trt_before_cdb_adj_nested2 <- stan_lmer(log(TFT) ~ el*scale(lr,scale=F)+scale(log(length),scale=F)+(el|item)+(el*scale(lr,scale=F)+scale(log(length),scale=F)|subj), test,cores=4,iter=4000,adapt_delta=0.999,refresh=-1,prior=cauchy(0,2.5),prior_intercept=cauchy(0,2.5),prior_covariance=decov(regularization=2)),9)
save(trt_before_cdb_adj_nested2,file="trt_before_cdb_adj_nested2.Rda")

# Regression counts

test <- subset(new, roi=="sluice" & stype=="cdb" & TRC > 0)
smry(trc_cdb_sluice <- stan_lmer(TRC~amb*el+scale(log(length),scale=F)+(amb*el|item)+(amb*el+scale(log(length),scale=F)|subj), test,cores=4,iter=4000,adapt_delta=0.999,refresh=-1,prior=cauchy(0,2.5),prior_intercept=cauchy(0,2.5),prior_covariance=decov(regularization=2)),5)
save(trc_cdb_sluice,file="trc_cdb_sluice.Rda")
smry(trc_cdb_sluice_nested <- stan_lmer(TRC~ c1+c2+el+scale(log(length),scale=F)+(c1+c2+el|item)+(c1+c2+el+scale(log(length),scale=F)|subj), test,cores=4,iter=4000,adapt_delta=0.999,refresh=-1,prior=cauchy(0,2.5),prior_intercept=cauchy(0,2.5),prior_covariance=decov(regularization=2)),9)
save(trc_cdb_sluice_nested,file="trc_cdb_sluice_nested.Rda")

# Summed log reading times across TLA antecedent regions

new$ambi <- ifelse(new$roi%in%c("np1_c", "adj", "verb"),"ambi","other")
ambi <- subset(new, ambi == "ambi")
ambir <- ddply(ambi, .(subj,item,el,amb,TRIAL_INDEX,condition), summarise, sdwell=sum(TFT),slen=sum(lengthb))
ambir$c1<-ifelse(ambir$condition=="a",1,ifelse(ambir$condition=="b",-1,0))
ambir$c2<-ifelse(ambir$condition=="c",1,ifelse(ambir$condition=="d",-1,0))
ambir$reread <- ifelse(ambir$sdwell > 0, 1, 0)
ddply(.data=ambir, .(el,amb),summarise,rr=mean(reread))
ambir2 <- subset(ambir, sdwell > 0)
smry(trt_after_antecedent <- stan_lmer(log(sdwell)~el*amb+scale(log(slen),scale=F)+(amb*el+scale(log(slen),scale=F)|subj)+(amb*el|item), ambir2,cores=4,iter=4000,adapt_delta=0.999,refresh=-1,prior=cauchy(0,2.5),prior_intercept=cauchy(0,2.5),prior_covariance=decov(regularization=2)),5)
save(trt_after_antecedent,file="trt_after_antecedent.Rda")
