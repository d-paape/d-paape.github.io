# Plot for comparison of Paape (2016) and Experiment 2
# See below for calculations

mean <- c(-23.63,-35)
high <- c(-0.6,0)
low <- c(-46.68,-68)
df <- data.frame(mean,high,low,c(1,2))
colnames(df)[4] <- c("exp")

library(ggplot2)
library(R.utils)

f <- theme(axis.title.x = element_text(face="bold", size=8),
           axis.text.x = element_text(color="black",size=9),
           axis.title.y = element_text(face="bold", size=9),
           axis.text.y = element_text(color="black",size=8),
           plot.title = element_text(face="bold",lineheight=.8,size=9))

tiff("comparison.tif",height=4,width=4,units='in',res=300,compression="lzw",family="Times New Roman")

  ggplot(df,aes(x=exp, y=mean)) + 
  theme_bw()+
  geom_errorbar(aes(ymin=low, ymax=high), width=.1,size=.7,color="#FF6600") +
  f+
  geom_point(size=4,fill="white",color="#FF6600",shape=15) +
  scale_x_discrete(labels=c("Paape (2016)","Experiment 2"),limits=c("old","new"))+
  scale_y_continuous(breaks=seq(-120,10, 10))+
  ylab("Interaction size in ms")+
  xlab("Study")
  
  dev.off()

# Old data from Paape (2016)

mean <- -0.02
high <- 0.00
low <- -0.05

m1 <- exp(5.66+0.01+0.01+mean)
m2 <- exp(5.66-0.01+0.01-mean)
m3 <- exp(5.66+0.01-0.01-mean)
m4 <- exp(5.66-0.01-0.01+mean)
(m1-m2)-(m3-m4)

m1 <- exp(5.66+0.01+0.01+high)
m2 <- exp(5.66-0.01+0.01-high)
m3 <- exp(5.66+0.01-0.01-high)
m4 <- exp(5.66-0.01-0.01+high)
(m1-m2)-(m3-m4)

m1 <- exp(5.66+0.01+0.01+low)
m2 <- exp(5.66-0.01+0.01-low)
m3 <- exp(5.66+0.01-0.01-low)
m4 <- exp(5.66-0.01-0.01+low)
(m1-m2)-(m3-m4)